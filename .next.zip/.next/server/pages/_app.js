"use strict";
(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 4752:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ AppErrorBoundary)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8930);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _chakra_ui_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4513);
/* harmony import */ var _chakra_ui_icons__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_chakra_ui_icons__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6290);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_editor_Editor__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2445);
/* harmony import */ var _utils_bugsnag__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2034);







class AppErrorBoundary extends react__WEBPACK_IMPORTED_MODULE_1__.Component {
    state = {
        hasError: false
    };
    static getDerivedStateFromError(error) {
        _utils_bugsnag__WEBPACK_IMPORTED_MODULE_6__/* .bugsnagClient.notify */ .R.notify(error);
        return {
            hasError: true
        };
    }
    render() {
        if (this.state.hasError) {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Flex, {
                ..._components_editor_Editor__WEBPACK_IMPORTED_MODULE_5__/* .gridStyles */ .m,
                p: 0,
                alignItems: "center",
                justifyContent: "center",
                flex: 1,
                position: "relative",
                height: "100vh",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Stack, {
                    alignItems: "center",
                    direction: "row",
                    spacing: 8,
                    bg: "white",
                    px: 6,
                    py: 6,
                    boxShadow: "sm",
                    width: "lg",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Box, {
                            as: react_icons_fa__WEBPACK_IMPORTED_MODULE_4__.FaBomb,
                            fontSize: "100px"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Box, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                                    children: "Oups…"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                "Something went wrong! Clear cache and refresh.",
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.Button, {
                                    onClick: ()=>{
                                        localStorage.clear();
                                        window.location.reload();
                                    },
                                    variant: "outline",
                                    rightIcon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_icons__WEBPACK_IMPORTED_MODULE_3__.CheckCircleIcon, {
                                        path: ""
                                    }),
                                    size: "sm",
                                    mt: 4,
                                    display: "block",
                                    children: "Clear & reload"
                                })
                            ]
                        })
                    ]
                })
            });
        }
        return this.props.children;
    }
};


/***/ }),

/***/ 1279:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _rematch_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9710);
/* harmony import */ var _rematch_core__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_rematch_core__WEBPACK_IMPORTED_MODULE_0__);

const app = (0,_rematch_core__WEBPACK_IMPORTED_MODULE_0__.createModel)({
    state: {
        showLayout: true,
        showCode: false,
        inputTextFocused: false,
        overlay: undefined
    },
    reducers: {
        toggleBuilderMode (state) {
            return {
                ...state,
                showLayout: !state.showLayout
            };
        },
        toggleCodePanel (state) {
            return {
                ...state,
                showCode: !state.showCode
            };
        },
        toggleInputText (state) {
            return {
                ...state,
                inputTextFocused: !state.inputTextFocused
            };
        },
        setOverlay (state, overlay) {
            return {
                ...state,
                overlay
            };
        },
        "components/deleteComponent": (state)=>{
            return {
                ...state,
                overlay: undefined
            };
        },
        "@@redux-undo/UNDO": (state)=>{
            return {
                ...state,
                overlay: undefined
            };
        }
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (app);


/***/ }),

/***/ 408:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export INITIAL_COMPONENTS */
/* harmony import */ var _rematch_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9710);
/* harmony import */ var _rematch_core__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_rematch_core__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var immer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9810);
/* harmony import */ var _utils_defaultProps__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9737);
/* harmony import */ var _templates__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8635);
/* harmony import */ var _utils_generateId__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(427);
/* harmony import */ var _utils_recursive__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3881);
/* harmony import */ var lodash_omit__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3901);
/* harmony import */ var lodash_omit__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(lodash_omit__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([immer__WEBPACK_IMPORTED_MODULE_1__]);
immer__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







const DEFAULT_ID = "root";
const INITIAL_COMPONENTS = {
    root: {
        id: DEFAULT_ID,
        parent: DEFAULT_ID,
        type: "Box",
        children: [],
        props: {}
    }
};
const components = (0,_rematch_core__WEBPACK_IMPORTED_MODULE_0__.createModel)({
    state: {
        components: INITIAL_COMPONENTS,
        selectedId: DEFAULT_ID
    },
    reducers: {
        reset (state, components) {
            return {
                ...state,
                components: components || INITIAL_COMPONENTS,
                selectedId: DEFAULT_ID
            };
        },
        loadDemo (state, type) {
            return {
                ...state,
                selectedId: "comp-root",
                components: _templates__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z[type]
            };
        },
        resetProps (state, componentId) {
            return (0,immer__WEBPACK_IMPORTED_MODULE_1__["default"])(state, (draftState)=>{
                const component = draftState.components[componentId];
                const { form , ...defaultProps } = _utils_defaultProps__WEBPACK_IMPORTED_MODULE_2__/* .DEFAULT_PROPS */ .n[component.type] || {};
                draftState.components[componentId].props = defaultProps || {};
            });
        },
        updateProps (state, payload) {
            return (0,immer__WEBPACK_IMPORTED_MODULE_1__["default"])(state, (draftState)=>{
                draftState.components[payload.id].props[payload.name] = payload.value;
            });
        },
        deleteProps (state, payload) {
            return {
                ...state,
                components: {
                    ...state.components,
                    [payload.id]: {
                        ...state.components[payload.id],
                        props: lodash_omit__WEBPACK_IMPORTED_MODULE_5___default()(state.components[payload.id].props, payload.name)
                    }
                }
            };
        },
        deleteComponent (state, componentId) {
            if (componentId === "root") {
                return state;
            }
            return (0,immer__WEBPACK_IMPORTED_MODULE_1__["default"])(state, (draftState)=>{
                let component = draftState.components[componentId];
                // Remove self
                if (component && component.parent) {
                    const children = draftState.components[component.parent].children.filter((id)=>id !== componentId);
                    draftState.components[component.parent].children = children;
                }
                draftState.selectedId = DEFAULT_ID;
                draftState.components = (0,_utils_recursive__WEBPACK_IMPORTED_MODULE_4__/* .deleteComponent */ .v)(component, draftState.components);
            });
        },
        moveComponent (state, payload) {
            if (state.components[payload.componentId].parent === payload.parentId || payload.parentId === payload.componentId) {
                return state;
            }
            return (0,immer__WEBPACK_IMPORTED_MODULE_1__["default"])(state, (draftState)=>{
                const previousParentId = draftState.components[payload.componentId].parent;
                const children = draftState.components[previousParentId].children.filter((id)=>id !== payload.componentId);
                // Remove id from previous parent
                draftState.components[previousParentId].children = children;
                // Update parent id
                draftState.components[payload.componentId].parent = payload.parentId;
                // Add new child
                draftState.components[payload.parentId].children.push(payload.componentId);
            });
        },
        moveSelectedComponentChildren (state, payload) {
            return (0,immer__WEBPACK_IMPORTED_MODULE_1__["default"])(state, (draftState)=>{
                const selectedComponent = draftState.components[draftState.selectedId];
                selectedComponent.children.splice(payload.toIndex, 0, selectedComponent.children.splice(payload.fromIndex, 1)[0]);
            });
        },
        addComponent (state, payload) {
            return (0,immer__WEBPACK_IMPORTED_MODULE_1__["default"])(state, (draftState)=>{
                const id = payload.testId || (0,_utils_generateId__WEBPACK_IMPORTED_MODULE_6__/* .generateId */ .O)();
                const { form , ...defaultProps } = _utils_defaultProps__WEBPACK_IMPORTED_MODULE_2__/* .DEFAULT_PROPS */ .n[payload.type] || {};
                draftState.selectedId = id;
                draftState.components[payload.parentName].children.push(id);
                draftState.components[id] = {
                    id,
                    props: defaultProps || {},
                    children: [],
                    type: payload.type,
                    parent: payload.parentName,
                    rootParentType: payload.rootParentType || payload.type
                };
            });
        },
        addMetaComponent (state, payload) {
            return (0,immer__WEBPACK_IMPORTED_MODULE_1__["default"])(state, (draftState)=>{
                draftState.selectedId = payload.root;
                draftState.components[payload.parent].children.push(payload.root);
                draftState.components = {
                    ...draftState.components,
                    ...payload.components
                };
            });
        },
        select (state, selectedId) {
            return {
                ...state,
                selectedId
            };
        },
        unselect (state) {
            return {
                ...state,
                selectedId: DEFAULT_ID
            };
        },
        selectParent (state) {
            const selectedComponent = state.components[state.selectedId];
            return {
                ...state,
                selectedId: state.components[selectedComponent.parent].id
            };
        },
        duplicate (state) {
            return (0,immer__WEBPACK_IMPORTED_MODULE_1__["default"])(state, (draftState)=>{
                const selectedComponent = draftState.components[draftState.selectedId];
                if (selectedComponent.id !== DEFAULT_ID) {
                    const parentElement = draftState.components[selectedComponent.parent];
                    const { newId , clonedComponents  } = (0,_utils_recursive__WEBPACK_IMPORTED_MODULE_4__/* .duplicateComponent */ .O)(selectedComponent, draftState.components);
                    draftState.components = {
                        ...draftState.components,
                        ...clonedComponents
                    };
                    draftState.components[parentElement.id].children.push(newId);
                }
            });
        },
        setComponentName (state, payload) {
            return (0,immer__WEBPACK_IMPORTED_MODULE_1__["default"])(state, (draftState)=>{
                const component = draftState.components[payload.componentId];
                component.componentName = payload.name;
            });
        },
        hover (state, componentId) {
            return {
                ...state,
                hoveredId: componentId
            };
        },
        unhover (state) {
            return {
                ...state,
                hoveredId: undefined
            };
        }
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (components);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2640:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _app__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1279);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(408);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components__WEBPACK_IMPORTED_MODULE_1__]);
_components__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const index = {
    app: _app__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z,
    components: _components__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (index);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 738:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "YS": () => (/* binding */ wrapper)
/* harmony export */ });
/* unused harmony exports storeConfig, makeStore */
/* harmony import */ var _rematch_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9710);
/* harmony import */ var _rematch_core__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_rematch_core__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6695);
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(redux__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var redux_undo__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8497);
/* harmony import */ var redux_undo__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(redux_undo__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var redux_persist__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4161);
/* harmony import */ var redux_persist__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(redux_persist__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8936);
/* harmony import */ var redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5648);
/* harmony import */ var next_redux_wrapper__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_redux_wrapper__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _models__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2640);
/* harmony import */ var _utils_undo__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5054);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_models__WEBPACK_IMPORTED_MODULE_6__]);
_models__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];








const version = parseInt("1" || 0, 10);
const persistConfig = {
    key: `openchakra_v${version}`,
    storage: (redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_4___default()),
    whitelist: [
        "present"
    ],
    version,
    throttle: 500
};
const persistPlugin = {
    onStoreCreated (store) {
        if (false) {}
    }
};
const storeConfig = {
    models: _models__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z,
    redux: {
        // @ts-ignore
        combineReducers: (reducers)=>{
            return (0,redux__WEBPACK_IMPORTED_MODULE_1__.combineReducers)({
                ...reducers,
                components: (0,redux_persist__WEBPACK_IMPORTED_MODULE_3__.persistReducer)(persistConfig, redux_undo__WEBPACK_IMPORTED_MODULE_2___default()(reducers.components, {
                    limit: 10,
                    filter: _utils_undo__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z
                }))
            });
        }
    },
    plugins: [
        persistPlugin
    ]
};
// @ts-ignore
const makeStore = ()=>(0,_rematch_core__WEBPACK_IMPORTED_MODULE_0__.init)(storeConfig);
const wrapper = (0,next_redux_wrapper__WEBPACK_IMPORTED_MODULE_5__.createWrapper)(makeStore);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2957:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8930);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _chakra_ui_theme__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3236);
/* harmony import */ var _chakra_ui_theme__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_chakra_ui_theme__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _core_store__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(738);
/* harmony import */ var _utils_bugsnag__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2034);
/* harmony import */ var _components_errorBoundaries_AppErrorBoundary__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4752);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_core_store__WEBPACK_IMPORTED_MODULE_4__]);
_core_store__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];









const Main = ({ Component , pageProps  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_utils_bugsnag__WEBPACK_IMPORTED_MODULE_5__/* .ErrorBoundary */ .S, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__.ChakraProvider, {
            resetCSS: true,
            theme: (_chakra_ui_theme__WEBPACK_IMPORTED_MODULE_3___default()),
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_errorBoundaries_AppErrorBoundary__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                    ...pageProps
                })
            })
        })
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_core_store__WEBPACK_IMPORTED_MODULE_4__/* .wrapper.withRedux */ .YS.withRedux(Main));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8635:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ src_templates)
});

;// CONCATENATED MODULE: ./src/templates/onboarding.ts
const onboarding = {
    root: {
        id: "root",
        parent: "root",
        type: "Box",
        children: [
            "comp-root",
            "comp-K6GOMRTOCHZHD"
        ],
        props: {
            backgroundColor: "gray.100"
        }
    },
    "comp-1580479567": {
        id: "comp-1580479567",
        props: {
            bg: "#ffffff",
            borderRadius: "lg",
            width: "sm",
            minHeight: "sm",
            border: "1px solid lightgrey",
            overflow: "hidden"
        },
        children: [
            "comp-1580479581",
            "comp-1580479627"
        ],
        type: "Box",
        parent: "comp-K6H1HKZ1MFW94"
    },
    "comp-1580479581": {
        id: "comp-1580479581",
        props: {},
        children: [
            "comp-1580479588"
        ],
        type: "Box",
        parent: "comp-1580479567"
    },
    "comp-1580479588": {
        id: "comp-1580479588",
        props: {
            size: "100px",
            fallbackSrc: "https://via.placeholder.com/150",
            src: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
            width: "100%",
            height: "auto",
            minHeight: "245px"
        },
        children: [],
        type: "Image",
        parent: "comp-1580479581"
    },
    "comp-1580479627": {
        id: "comp-1580479627",
        props: {
            p: "5",
            pb: "8"
        },
        children: [
            "comp-1580479631",
            "comp-1580479743",
            "comp-1580479791",
            "comp-1580479811", 
        ],
        type: "Box",
        parent: "comp-1580479567"
    },
    "comp-1580479631": {
        id: "comp-1580479631",
        props: {
            display: "flex",
            justifyContent: "flex-start",
            alignItems: "flex-start",
            mb: "1",
            flexDirection: "row"
        },
        children: [
            "comp-1580479639",
            "comp-1580479654"
        ],
        type: "Box",
        parent: "comp-1580479627"
    },
    "comp-1580479639": {
        id: "comp-1580479639",
        props: {
            children: "NEW",
            variant: "subtle",
            colorScheme: "teal",
            mr: "2",
            borderRadius: "lg",
            pl: "2",
            pr: "2"
        },
        children: [],
        type: "Badge",
        parent: "comp-1580479631"
    },
    "comp-1580479654": {
        id: "comp-1580479654",
        props: {
            children: "3 BEDS • 2 BATHS",
            color: "gray.500",
            fontSize: "xs"
        },
        children: [],
        type: "Text",
        parent: "comp-1580479631"
    },
    "comp-1580479743": {
        id: "comp-1580479743",
        props: {
            children: "Modern home in city center",
            fontWeight: "bold",
            fontSize: "xl"
        },
        children: [],
        type: "Text",
        parent: "comp-1580479627"
    },
    "comp-1580479791": {
        id: "comp-1580479791",
        props: {
            children: "$119/night",
            fontSize: "sm",
            mb: "3"
        },
        children: [],
        type: "Text",
        parent: "comp-1580479627"
    },
    "comp-1580479811": {
        id: "comp-1580479811",
        props: {
            display: "flex",
            alignItems: "center",
            mb: "",
            flexDirection: "row",
            justifyContent: "flex-start"
        },
        children: [
            "comp-1580479816",
            "comp-1580479832",
            "comp-1580479862"
        ],
        type: "Box",
        parent: "comp-1580479627"
    },
    "comp-1580479816": {
        id: "comp-1580479816",
        props: {
            icon: "StarIcon",
            color: "yellow.400",
            mr: "1"
        },
        children: [],
        type: "Icon",
        parent: "comp-1580479811"
    },
    "comp-1580479832": {
        id: "comp-1580479832",
        props: {
            children: "4.84",
            fontWeight: "bold",
            mr: "1"
        },
        children: [],
        type: "Text",
        parent: "comp-1580479811"
    },
    "comp-1580479862": {
        id: "comp-1580479862",
        props: {
            children: "(190)",
            fontSize: "sm"
        },
        children: [],
        type: "Text",
        parent: "comp-1580479811"
    },
    "comp-K6GOHZ8TESH7P": {
        id: "comp-K6GOHZ8TESH7P",
        props: {
            isInline: true,
            spacing: "3"
        },
        children: [
            "comp-K6GOJIZK48606",
            "comp-K6GOMJN7JIXFL"
        ],
        type: "Stack",
        parent: "root",
        rootParentType: "Stack"
    },
    "comp-K6GOIFAQVGRYM": {
        id: "comp-K6GOIFAQVGRYM",
        props: {
            size: "md",
            name: "B A"
        },
        children: [
            "comp-K6GOIKKDQ4493"
        ],
        type: "Avatar",
        parent: "comp-K6GOI5NIER4LV",
        rootParentType: "Avatar"
    },
    "comp-K6GOIGUCZB1SL": {
        id: "comp-K6GOIGUCZB1SL",
        props: {
            size: "md",
            name: "D SSQDDFFDQ"
        },
        children: [
            "comp-K6GOIMB85D7K4"
        ],
        type: "Avatar",
        parent: "comp-K6GOI5NIER4LV",
        rootParentType: "Avatar"
    },
    "comp-K6GOIIBO0XHI7": {
        id: "comp-K6GOIIBO0XHI7",
        props: {
            size: "md"
        },
        children: [],
        type: "Avatar",
        parent: "comp-K6GOI5NIER4LV",
        rootParentType: "Avatar"
    },
    "comp-K6GOIKKDQ4493": {
        id: "comp-K6GOIKKDQ4493",
        props: {
            bg: "green.500",
            size: "1.25em",
            borderColor: "white"
        },
        children: [],
        type: "AvatarBadge",
        parent: "comp-K6GOIFAQVGRYM",
        rootParentType: "Avatar"
    },
    "comp-K6GOIMB85D7K4": {
        id: "comp-K6GOIMB85D7K4",
        props: {
            bg: "red.300",
            size: "1.25em",
            borderColor: "white"
        },
        children: [],
        type: "AvatarBadge",
        parent: "comp-K6GOIGUCZB1SL",
        rootParentType: "Avatar"
    },
    "comp-K6GOJIZK48606": {
        children: [
            "comp-K6GOJIZKP3TP4",
            "comp-K6GOJIZKBP51K",
            "comp-K6GOJIZKFGTBB", 
        ],
        type: "Alert",
        parent: "comp-K6GPRW4QAMBNY",
        id: "comp-K6GOJIZK48606",
        props: {
            variant: "left-accent",
            status: "success",
            width: "",
            mt: "10"
        },
        rootParentType: "Alert"
    },
    "comp-K6GOJIZKP3TP4": {
        children: [],
        type: "AlertIcon",
        parent: "comp-K6GOJIZK48606",
        id: "comp-K6GOJIZKP3TP4",
        props: {},
        rootParentType: "Alert"
    },
    "comp-K6GOJIZKBP51K": {
        children: [],
        type: "AlertTitle",
        parent: "comp-K6GOJIZK48606",
        id: "comp-K6GOJIZKBP51K",
        props: {
            children: "Lorem IpsumD",
            mr: 1
        },
        rootParentType: "Alert"
    },
    "comp-K6GOJIZKFGTBB": {
        children: [],
        type: "AlertDescription",
        parent: "comp-K6GOJIZK48606",
        id: "comp-K6GOJIZKFGTBB",
        props: {
            children: "Lorem Ipsum"
        },
        rootParentType: "Alert"
    },
    "comp-K6GOMJN7PJCDF": {
        children: [],
        type: "FormLabel",
        parent: "comp-K6GOMJN7JIXFL",
        id: "comp-K6GOMJN7PJCDF",
        props: {
            children: "Email"
        },
        rootParentType: "FormControl"
    },
    "comp-K6GOMJN7RTBUI": {
        children: [],
        type: "Input",
        parent: "comp-K6GP5NLNTDJFV",
        id: "comp-K6GOMJN7RTBUI",
        props: {
            size: "md",
            as: "input",
            variant: "outline",
            width: "100%",
            focusBorderColor: "blue.500",
            errorBorderColor: "red.500",
            placeholder: "Your email"
        },
        rootParentType: "FormControl"
    },
    "comp-K6GOMJN724L5A": {
        children: [],
        type: "FormHelperText",
        parent: "comp-K6GOMJN7JIXFL",
        id: "comp-K6GOMJN724L5A",
        props: {
            children: "Toggle the invalid props in the side panel "
        },
        rootParentType: "FormControl"
    },
    "comp-K6GOMJN725CHT": {
        children: [],
        type: "FormErrorMessage",
        parent: "comp-K6GOMJN7JIXFL",
        id: "comp-K6GOMJN725CHT",
        props: {
            children: "Invalid email"
        },
        rootParentType: "FormControl"
    },
    "comp-K6GOMRTOCHZHD": {
        id: "comp-K6GOMRTOCHZHD",
        props: {
            p: 10,
            gap: "6",
            templateColumns: "repeat(auto-fit, minmax(350px, 1fr))"
        },
        children: [
            "comp-K6GXBDLT2XCNC",
            "comp-K6H0JNXQ74O61",
            "comp-K6H1R04NDVRXG",
            "comp-K6H1HKZ1MFW94", 
        ],
        type: "Grid",
        parent: "root",
        rootParentType: "Grid"
    },
    "comp-K6GOPXN2COS0O": {
        id: "comp-K6GOPXN2COS0O",
        props: {
            isInline: true,
            spacing: "4",
            p: "",
            m: "",
            mt: "10",
            justifyContent: "flex-start",
            alignItems: "center"
        },
        children: [
            "comp-K6GOQACVR8I88",
            "comp-K6GOQCQRD62NL"
        ],
        type: "Stack",
        parent: "comp-K6GPRW4QAMBNY",
        rootParentType: "Stack"
    },
    "comp-K6GOQACVR8I88": {
        id: "comp-K6GOQACVR8I88",
        props: {
            color: "blue",
            size: "md",
            isChecked: true
        },
        children: [],
        type: "Switch",
        parent: "comp-K6GOPXN2COS0O",
        rootParentType: "Switch"
    },
    "comp-K6GOQCQRD62NL": {
        id: "comp-K6GOQCQRD62NL",
        props: {
            color: "red",
            size: "md",
            isChecked: true
        },
        children: [],
        type: "Switch",
        parent: "comp-K6GOPXN2COS0O",
        rootParentType: "Switch"
    },
    "comp-K6GP5NLNTDJFV": {
        id: "comp-K6GP5NLNTDJFV",
        props: {},
        children: [
            "comp-K6GOMJN7RTBUI",
            "comp-K6GP5TB58TQP4"
        ],
        type: "InputGroup",
        parent: "comp-K6GOMJN7JIXFL",
        rootParentType: "Input"
    },
    "comp-K6GP5TB58TQP4": {
        id: "comp-K6GP5TB58TQP4",
        props: {},
        children: [
            "comp-K6GP60GCOFWJI"
        ],
        type: "InputRightElement",
        parent: "comp-K6GP5NLNTDJFV",
        rootParentType: "Input"
    },
    "comp-K6GP60GCOFWJI": {
        id: "comp-K6GP60GCOFWJI",
        props: {
            icon: "EmailIcon",
            color: "blackAlpha.300"
        },
        children: [],
        type: "Icon",
        parent: "comp-K6GP5TB58TQP4",
        rootParentType: "Icon"
    },
    "comp-root": {
        id: "comp-root",
        props: {
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            textAlign: "center",
            fontStyle: null,
            fontWeight: null,
            mt: "4"
        },
        children: [
            "comp-K6H1NISD15XAG",
            "comp-K6H1NSQY3KC7W"
        ],
        type: "Flex",
        parent: "root",
        rootParentType: "Flex"
    },
    "comp-K6GPAPKNQACEE": {
        id: "comp-K6GPAPKNQACEE",
        props: {
            children: "⚡️Welcome to OpenChakra",
            fontSize: "3xl",
            fontWeight: "bold"
        },
        children: [],
        type: "Text",
        parent: "comp-K6H1NISD15XAG",
        rootParentType: "Text"
    },
    "comp-K6GPCGKZ5S4UA": {
        id: "comp-K6GPCGKZ5S4UA",
        props: {
            children: "BETA",
            variant: "subtle",
            colorScheme: "pink",
            ml: "1"
        },
        children: [],
        type: "Badge",
        parent: "comp-K6H1NISD15XAG",
        rootParentType: "Badge"
    },
    "comp-K6GXBDLT2XCNC": {
        id: "comp-K6GXBDLT2XCNC",
        props: {},
        children: [
            "comp-K6GXDV4IMW2CP"
        ],
        type: "Stack",
        parent: "comp-K6GOMRTOCHZHD",
        rootParentType: "Stack"
    },
    "comp-K6GXDV4IMW2CP": {
        id: "comp-K6GXDV4IMW2CP",
        props: {
            backgroundColor: "white",
            boxShadow: "sm",
            borderRadius: "lg",
            p: "",
            pl: "3",
            pr: "3",
            pt: "5",
            pb: "5"
        },
        children: [
            "comp-K6GXI36J9KZND",
            "comp-K6GYT6R9XZ4FQ"
        ],
        type: "Box",
        parent: "comp-K6GXBDLT2XCNC",
        rootParentType: "Box"
    },
    "comp-K6GXFBY5JLD6C": {
        id: "comp-K6GXFBY5JLD6C",
        props: {
            isInline: false,
            justifyContent: "flex-start",
            alignItems: "flex-start",
            ml: "",
            spacing: "2"
        },
        children: [
            "comp-K6GZFELGGUNO9",
            "comp-K6GXFJ7TPU8HD",
            "comp-K6H0BMT29TH3Z", 
        ],
        type: "Stack",
        parent: "comp-K6GYT6R9XZ4FQ",
        rootParentType: "Stack"
    },
    "comp-K6GXFJ7TPU8HD": {
        id: "comp-K6GXFJ7TPU8HD",
        props: {
            children: "Drag any component from the left hand panel into this editor. Then start interacting with them: try to drop the Avatar component in this box…",
            fontSize: "md",
            color: "gray.600"
        },
        children: [],
        type: "Text",
        parent: "comp-K6GXFBY5JLD6C",
        rootParentType: "Text"
    },
    "comp-K6GXHPLKU3KD7": {
        id: "comp-K6GXHPLKU3KD7",
        props: {
            icon: "ChevronLeftIcon"
        },
        children: [],
        type: "Icon",
        parent: "comp-K6GXI36J9KZND",
        rootParentType: "Icon"
    },
    "comp-K6GXI36J9KZND": {
        id: "comp-K6GXI36J9KZND",
        props: {
            display: "flex",
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "flex-start",
            pb: "2"
        },
        children: [
            "comp-K6GXHPLKU3KD7",
            "comp-K6H1DN4WK66BJ"
        ],
        type: "Flex",
        parent: "comp-K6GXDV4IMW2CP",
        rootParentType: "Flex"
    },
    "comp-K6GYF54LO8XHL": {
        id: "comp-K6GYF54LO8XHL",
        props: {
            ml: "",
            isInline: false,
            spacing: "2"
        },
        children: [
            "comp-K6GYJVZZPAWEH",
            "comp-K6GYL9G557J57"
        ],
        type: "Stack",
        parent: "comp-K6GYT6R9XZ4FQ",
        rootParentType: "Stack"
    },
    "comp-K6GYJVZZPAWEH": {
        id: "comp-K6GYJVZZPAWEH",
        props: {
            children: "Preset",
            size: "md",
            variant: "subtle",
            isInline: false,
            colorScheme: "whatsapp"
        },
        children: [],
        type: "Tag",
        parent: "comp-K6GYF54LO8XHL",
        rootParentType: "Tag"
    },
    "comp-K6GYL9G557J57": {
        id: "comp-K6GYL9G557J57",
        props: {
            children: "A preset is a group of components (like Alert). Just drop a preset to easily setup a complexe component like this:",
            color: "gray.600"
        },
        children: [],
        type: "Text",
        parent: "comp-K6GYF54LO8XHL",
        rootParentType: "Text"
    },
    "comp-K6GYT6R9XZ4FQ": {
        id: "comp-K6GYT6R9XZ4FQ",
        props: {
            ml: "4",
            spacing: "2",
            mt: "4",
            mr: "4"
        },
        children: [
            "comp-K6GXFBY5JLD6C",
            "comp-K6GYF54LO8XHL",
            "comp-K6H058BAEDGV1", 
        ],
        type: "Stack",
        parent: "comp-K6GXDV4IMW2CP",
        rootParentType: "Stack"
    },
    "comp-K6GZ3EKNXAMK3": {
        children: [],
        type: "AlertIcon",
        parent: "comp-K6GZ3EKNLDRNJ",
        id: "comp-K6GZ3EKNXAMK3",
        props: {},
        rootParentType: "Alert"
    },
    "comp-K6GZ3EKNM193L": {
        children: [],
        type: "AlertTitle",
        parent: "comp-K6GZ3EKNLDRNJ",
        id: "comp-K6GZ3EKNM193L",
        props: {
            children: "Lorem Ipsum",
            mr: 1
        },
        rootParentType: "Alert"
    },
    "comp-K6GZ3EKNST65I": {
        children: [],
        type: "AlertDescription",
        parent: "comp-K6GZ3EKNLDRNJ",
        id: "comp-K6GZ3EKNST65I",
        props: {
            children: "Lorem Ipsum"
        },
        rootParentType: "Alert"
    },
    "comp-K6GZFELGGUNO9": {
        id: "comp-K6GZFELGGUNO9",
        props: {
            children: "Drag and Drop!",
            size: "md",
            variant: "subtle",
            colorScheme: "whatsapp",
            borderRadius: "sm",
            fontSize: "sm"
        },
        children: [],
        type: "Tag",
        parent: "comp-K6GXFBY5JLD6C",
        rootParentType: "Tag"
    },
    "comp-K6H058BAEDGV1": {
        children: [
            "comp-K6H058BALZ1ZY",
            "comp-K6H058BADYEBT",
            "comp-K6H058BA2BOTV", 
        ],
        type: "Alert",
        parent: "root",
        id: "comp-K6H058BAEDGV1",
        props: {
            variant: "left-accent",
            status: "success"
        },
        rootParentType: "Alert"
    },
    "comp-K6H058BALZ1ZY": {
        children: [],
        type: "AlertIcon",
        parent: "comp-K6H058BAEDGV1",
        id: "comp-K6H058BALZ1ZY",
        props: {},
        rootParentType: "Alert"
    },
    "comp-K6H058BADYEBT": {
        children: [],
        type: "AlertTitle",
        parent: "comp-K6H058BAEDGV1",
        id: "comp-K6H058BADYEBT",
        props: {
            children: "Alert!",
            mr: 1
        },
        rootParentType: "Alert"
    },
    "comp-K6H058BA2BOTV": {
        children: [],
        type: "AlertDescription",
        parent: "comp-K6H058BAEDGV1",
        id: "comp-K6H058BA2BOTV",
        props: {
            children: "I'm an Alert preset"
        },
        rootParentType: "Alert"
    },
    "comp-K6H0BMT29TH3Z": {
        id: "comp-K6H0BMT29TH3Z",
        props: {
            width: "200px",
            display: "block",
            flexDirection: "column",
            alignItems: "flex-start",
            justifyContent: "flex-start",
            minWidth: "",
            backgroundColor: "gray.100",
            borderRadius: "lg",
            p: "3",
            minHeight: "60px"
        },
        children: [],
        type: "Box",
        parent: "comp-K6GXFBY5JLD6C",
        rootParentType: "Box"
    },
    "comp-K6H0JNXQ74O61": {
        id: "comp-K6H0JNXQ74O61",
        props: {
            mt: ""
        },
        children: [
            "comp-K6H0K8RWWJZI9"
        ],
        type: "Box",
        parent: "comp-K6GOMRTOCHZHD",
        rootParentType: "Box"
    },
    "comp-K6H0K8RWWJZI9": {
        id: "comp-K6H0K8RWWJZI9",
        props: {
            backgroundColor: "white",
            borderRadius: "lg",
            boxShadow: "sm",
            pl: "3",
            pr: "3",
            pt: "5",
            pb: "5"
        },
        children: [
            "comp-K6H0L0JI1C6Q8",
            "comp-K6H0PTU71NGNY"
        ],
        type: "Box",
        parent: "comp-K6H0JNXQ74O61",
        rootParentType: "Box"
    },
    "comp-K6H0L0JI1C6Q8": {
        id: "comp-K6H0L0JI1C6Q8",
        props: {
            display: "flex",
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "flex-end"
        },
        children: [
            "comp-K6H1E4X3P9NHB",
            "comp-K6H0L81XGIHU1"
        ],
        type: "Flex",
        parent: "comp-K6H0K8RWWJZI9",
        rootParentType: "Flex"
    },
    "comp-K6H0L81XGIHU1": {
        id: "comp-K6H0L81XGIHU1",
        props: {
            icon: "ChevronRightIcon"
        },
        children: [],
        type: "Icon",
        parent: "comp-K6H0L0JI1C6Q8",
        rootParentType: "Icon"
    },
    "comp-K6H0PTU71NGNY": {
        id: "comp-K6H0PTU71NGNY",
        props: {
            spacing: "4",
            ml: "4",
            mt: "4"
        },
        children: [
            "comp-K6H0PXX1VMIEO",
            "comp-K6H175A76GO7R",
            "comp-K6H0VNVDZ2TRH", 
        ],
        type: "Stack",
        parent: "comp-K6H0K8RWWJZI9",
        rootParentType: "Stack"
    },
    "comp-K6H0PXX1VMIEO": {
        id: "comp-K6H0PXX1VMIEO",
        props: {
            spacing: "2"
        },
        children: [
            "comp-K6H0Q3HFG0Q14",
            "comp-K6H0RNTHVY7IT"
        ],
        type: "Stack",
        parent: "comp-K6H0PTU71NGNY",
        rootParentType: "Stack"
    },
    "comp-K6H0Q3HFG0Q14": {
        id: "comp-K6H0Q3HFG0Q14",
        props: {
            children: "Update props & style",
            size: "md",
            variant: "subtle",
            colorScheme: "yellow"
        },
        children: [],
        type: "Tag",
        parent: "comp-K6H0PXX1VMIEO",
        rootParentType: "Tag"
    },
    "comp-K6H0RNTHVY7IT": {
        id: "comp-K6H0RNTHVY7IT",
        props: {
            children: "On the right hand side, you can find the inspectror panel. You will find the tools to edit the component's props and style.",
            fontSize: "md",
            color: "gray.600"
        },
        children: [],
        type: "Text",
        parent: "comp-K6H0PXX1VMIEO",
        rootParentType: "Text"
    },
    "comp-K6H0VNVDZ2TRH": {
        id: "comp-K6H0VNVDZ2TRH",
        props: {
            spacing: "2"
        },
        children: [
            "comp-K6H0VZBSG4SCN",
            "comp-K6H0WPDNKQ6CR"
        ],
        type: "Stack",
        parent: "comp-K6H0PTU71NGNY",
        rootParentType: "Stack"
    },
    "comp-K6H0VZBSG4SCN": {
        id: "comp-K6H0VZBSG4SCN",
        props: {
            children: "Sort components",
            size: "md",
            variant: "subtle",
            isInline: false,
            colorScheme: "yellow"
        },
        children: [],
        type: "Tag",
        parent: "comp-K6H0VNVDZ2TRH",
        rootParentType: "Tag"
    },
    "comp-K6H0WPDNKQ6CR": {
        id: "comp-K6H0WPDNKQ6CR",
        props: {
            children: "By clicking on a component containing children, you will see a Children panel appearing on the right. It enables sorting the children. ",
            color: "gray.600"
        },
        children: [],
        type: "Text",
        parent: "comp-K6H0VNVDZ2TRH",
        rootParentType: "Text"
    },
    "comp-K6H0YLJ6AL2ZP": {
        id: "comp-K6H0YLJ6AL2ZP",
        props: {
            size: "md",
            name: "Baptiste Adrien"
        },
        children: [
            "comp-K6H12NJ1K1WWT"
        ],
        type: "Avatar",
        parent: "comp-K6H0YIYKMTVPG",
        rootParentType: "Avatar"
    },
    "comp-K6H0YNHI4ZZEL": {
        id: "comp-K6H0YNHI4ZZEL",
        props: {
            size: "md",
            name: "Michel Gondry"
        },
        children: [],
        type: "Avatar",
        parent: "comp-K6H0YIYKMTVPG",
        rootParentType: "Avatar"
    },
    "comp-K6H0YPEUOUQ9S": {
        id: "comp-K6H0YPEUOUQ9S",
        props: {
            size: "md",
            name: "George Brassens"
        },
        children: [
            "comp-K6H12QD4UYFX0"
        ],
        type: "Avatar",
        parent: "comp-K6H0YIYKMTVPG",
        rootParentType: "Avatar"
    },
    "comp-K6H12NJ1K1WWT": {
        id: "comp-K6H12NJ1K1WWT",
        props: {
            bg: "green.500",
            size: "1.25em",
            borderColor: "white"
        },
        children: [],
        type: "AvatarBadge",
        parent: "comp-K6H0YLJ6AL2ZP",
        rootParentType: "Avatar"
    },
    "comp-K6H12QD4UYFX0": {
        id: "comp-K6H12QD4UYFX0",
        props: {
            bg: "green.500",
            size: "1.25em",
            borderColor: "white"
        },
        children: [],
        type: "AvatarBadge",
        parent: "comp-K6H0YPEUOUQ9S",
        rootParentType: "Avatar"
    },
    "comp-K6H175A76GO7R": {
        id: "comp-K6H175A76GO7R",
        props: {
            spacing: "2"
        },
        children: [
            "comp-K6H17C6VB8XQL",
            "comp-K6H17HIGGSUHM"
        ],
        type: "Stack",
        parent: "comp-K6H0PTU71NGNY",
        rootParentType: "Stack"
    },
    "comp-K6H17C6VB8XQL": {
        id: "comp-K6H17C6VB8XQL",
        props: {
            children: "Delete, reset and read doc",
            size: "md",
            variant: "subtle",
            colorScheme: "yellow"
        },
        children: [],
        type: "Tag",
        parent: "comp-K6H175A76GO7R",
        rootParentType: "Tag"
    },
    "comp-K6H17HIGGSUHM": {
        id: "comp-K6H17HIGGSUHM",
        props: {
            children: "Reach the yellow bar on the top to delete, reset and access the Chakra doc of each component.",
            color: "gray.600"
        },
        children: [],
        type: "Text",
        parent: "comp-K6H175A76GO7R",
        rootParentType: "Text"
    },
    "comp-K6H1DN4WK66BJ": {
        id: "comp-K6H1DN4WK66BJ",
        props: {
            size: "md",
            as: "h2",
            lineHeight: "shorter",
            fontWeight: "bold",
            fontFamily: "heading",
            children: "Component Panel"
        },
        children: [],
        type: "Heading",
        parent: "comp-K6GXI36J9KZND",
        rootParentType: "Heading"
    },
    "comp-K6H1E4X3P9NHB": {
        id: "comp-K6H1E4X3P9NHB",
        props: {
            size: "md",
            as: "h2",
            lineHeight: "shorter",
            fontWeight: "bold",
            fontFamily: "heading",
            children: "Inspector"
        },
        children: [],
        type: "Heading",
        parent: "comp-K6H0L0JI1C6Q8",
        rootParentType: "Heading"
    },
    "comp-K6H1HKZ1MFW94": {
        id: "comp-K6H1HKZ1MFW94",
        props: {
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            pt: "",
            mt: "",
            p: "10"
        },
        children: [
            "comp-K6H1HWQ2NE07P",
            "comp-1580479567"
        ],
        type: "Box",
        parent: "comp-K6GOMRTOCHZHD",
        rootParentType: "Box"
    },
    "comp-K6H1HWQ2NE07P": {
        id: "comp-K6H1HWQ2NE07P",
        props: {
            children: "With a bit of practice, you will able to design awesome components:",
            fontSize: "lg",
            fontWeight: null,
            lineHeight: "normal",
            textAlign: "center",
            mb: "5",
            color: "twitter.900",
            maxWidth: "sm"
        },
        children: [],
        type: "Text",
        parent: "comp-K6H1HKZ1MFW94",
        rootParentType: "Text"
    },
    "comp-K6H1NISD15XAG": {
        id: "comp-K6H1NISD15XAG",
        props: {
            display: "flex",
            flexDirection: "row",
            alignItems: "flex-start",
            justifyContent: "flex-start"
        },
        children: [
            "comp-K6GPAPKNQACEE",
            "comp-K6GPCGKZ5S4UA"
        ],
        type: "Flex",
        parent: "comp-root",
        rootParentType: "Flex"
    },
    "comp-K6H1NSQY3KC7W": {
        id: "comp-K6H1NSQY3KC7W",
        props: {
            children: "The Visual Editor for Chakra UI",
            color: "gray.500"
        },
        children: [],
        type: "Text",
        parent: "comp-root",
        rootParentType: "Text"
    },
    "comp-K6H1R04NDVRXG": {
        id: "comp-K6H1R04NDVRXG",
        props: {},
        children: [
            "comp-K6H1RE2JP0JEX"
        ],
        type: "Box",
        parent: "comp-K6GOMRTOCHZHD",
        rootParentType: "Box"
    },
    "comp-K6H1RE2JP0JEX": {
        id: "comp-K6H1RE2JP0JEX",
        props: {
            backgroundColor: "white",
            borderRadius: "lg",
            boxShadow: "sm",
            pl: "3",
            pr: "3",
            pt: "5",
            pb: "5"
        },
        children: [
            "comp-K6H1SPAU7FGTI",
            "comp-K6H1TRQ8GRP98"
        ],
        type: "Box",
        parent: "comp-K6H1R04NDVRXG",
        rootParentType: "Box"
    },
    "comp-K6H1SPAU7FGTI": {
        id: "comp-K6H1SPAU7FGTI",
        props: {
            display: "flex",
            flexDirection: "column",
            alignItems: "flex-start",
            justifyContent: "flex-start",
            pb: "",
            mb: "2",
            pl: "4"
        },
        children: [
            "comp-K6H1SW29GEL7E"
        ],
        type: "Flex",
        parent: "comp-K6H1RE2JP0JEX",
        rootParentType: "Flex"
    },
    "comp-K6H1SW29GEL7E": {
        id: "comp-K6H1SW29GEL7E",
        props: {
            size: "md",
            as: "h2",
            lineHeight: "shorter",
            fontWeight: "bold",
            fontFamily: "heading",
            children: "Editor"
        },
        children: [],
        type: "Heading",
        parent: "comp-K6H1SPAU7FGTI",
        rootParentType: "Heading"
    },
    "comp-K6H1TRQ8GRP98": {
        id: "comp-K6H1TRQ8GRP98",
        props: {
            spacing: "5",
            pl: "4",
            pt: "4"
        },
        children: [
            "comp-K6H1UG7QF7UP4",
            "comp-K6H1WTCRIIFNG",
            "comp-K6HM4MGL0S6AH", 
        ],
        type: "Stack",
        parent: "comp-K6H1RE2JP0JEX",
        rootParentType: "Stack"
    },
    "comp-K6H1UG7QF7UP4": {
        id: "comp-K6H1UG7QF7UP4",
        props: {
            spacing: "2"
        },
        children: [
            "comp-K6H1UMW2YLSAB",
            "comp-K6H1VU1P3OYRQ"
        ],
        type: "Stack",
        parent: "comp-K6H1TRQ8GRP98",
        rootParentType: "Stack"
    },
    "comp-K6H1UMW2YLSAB": {
        id: "comp-K6H1UMW2YLSAB",
        props: {
            children: "Builder mode",
            size: "md",
            variant: "solid",
            colorScheme: "facebook"
        },
        children: [],
        type: "Tag",
        parent: "comp-K6H1UG7QF7UP4",
        rootParentType: "Tag"
    },
    "comp-K6H1VU1P3OYRQ": {
        id: "comp-K6H1VU1P3OYRQ",
        props: {
            children: "The Builder mode adds extra padding/border to ease components selection (like containers).",
            color: "gray.600"
        },
        children: [],
        type: "Text",
        parent: "comp-K6H1UG7QF7UP4",
        rootParentType: "Text"
    },
    "comp-K6H1WTCRIIFNG": {
        id: "comp-K6H1WTCRIIFNG",
        props: {},
        children: [
            "comp-K6H1XCSNJY88G",
            "comp-K6H1XZB37JTJ4"
        ],
        type: "Stack",
        parent: "comp-K6H1TRQ8GRP98",
        rootParentType: "Stack"
    },
    "comp-K6H1XCSNJY88G": {
        id: "comp-K6H1XCSNJY88G",
        props: {
            children: "Code Panel",
            size: "md",
            variant: "solid",
            colorScheme: "facebook"
        },
        children: [],
        type: "Tag",
        parent: "comp-K6H1WTCRIIFNG",
        rootParentType: "Tag"
    },
    "comp-K6H1XZB37JTJ4": {
        id: "comp-K6H1XZB37JTJ4",
        props: {
            children: "Toggle the code panel for viewing the JSX/React code of your components. You can even export your code directly to CodeSandbox!",
            color: "gray.600"
        },
        children: [],
        type: "Text",
        parent: "comp-K6H1WTCRIIFNG",
        rootParentType: "Text"
    },
    "comp-K6HM4MGL0S6AH": {
        id: "comp-K6HM4MGL0S6AH",
        props: {
            spacing: "4"
        },
        children: [
            "comp-K6HMBS5MS8QPW",
            "comp-K6HM7KLJLO714",
            "comp-K6HMEG7J926M9",
            "comp-K6HM9HOFHX07Z",
            "comp-K6HMA6UCR000W", 
        ],
        type: "Stack",
        parent: "comp-K6H1TRQ8GRP98",
        rootParentType: "Stack"
    },
    "comp-K6HM71OF2R1BL": {
        id: "comp-K6HM71OF2R1BL",
        props: {
            children: "ctrl+z",
            size: "sm",
            variant: "subtle",
            colorScheme: "gray"
        },
        children: [],
        type: "Tag",
        parent: "comp-K6HM7KLJLO714",
        rootParentType: "Tag"
    },
    "comp-K6HM7F0ZLPGFE": {
        id: "comp-K6HM7F0ZLPGFE",
        props: {
            children: "cmd+z",
            size: "sm",
            variant: "subtle"
        },
        children: [],
        type: "Tag",
        parent: "comp-K6HM7KLJLO714",
        rootParentType: "Tag"
    },
    "comp-K6HM7KLJLO714": {
        id: "comp-K6HM7KLJLO714",
        props: {
            isInline: true
        },
        children: [
            "comp-K6HM7F0ZLPGFE",
            "comp-K6HM71OF2R1BL",
            "comp-K6HM92YJGOGIE", 
        ],
        type: "Stack",
        parent: "comp-K6HM4MGL0S6AH",
        rootParentType: "Stack"
    },
    "comp-K6HM92YJGOGIE": {
        id: "comp-K6HM92YJGOGIE",
        props: {
            children: "Undo",
            color: "gray.600"
        },
        children: [],
        type: "Text",
        parent: "comp-K6HM7KLJLO714",
        rootParentType: "Text"
    },
    "comp-K6HM9HOFHX07Z": {
        id: "comp-K6HM9HOFHX07Z",
        props: {
            isInline: true
        },
        children: [
            "comp-K6HM9L3VKMKHN",
            "comp-K6HM9Y9W5FRUJ"
        ],
        type: "Stack",
        parent: "comp-K6HM4MGL0S6AH",
        rootParentType: "Stack"
    },
    "comp-K6HM9L3VKMKHN": {
        id: "comp-K6HM9L3VKMKHN",
        props: {
            children: "b",
            size: "md",
            variant: "subtle",
            colorScheme: "gray"
        },
        children: [],
        type: "Tag",
        parent: "comp-K6HM9HOFHX07Z",
        rootParentType: "Tag"
    },
    "comp-K6HM9Y9W5FRUJ": {
        id: "comp-K6HM9Y9W5FRUJ",
        props: {
            children: "Toggle Builder mode",
            color: "gray.600"
        },
        children: [],
        type: "Text",
        parent: "comp-K6HM9HOFHX07Z",
        rootParentType: "Text"
    },
    "comp-K6HMA6UCR000W": {
        id: "comp-K6HMA6UCR000W",
        props: {
            isInline: true
        },
        children: [
            "comp-K6HMAAF672VE5",
            "comp-K6HMAKMTZWD8Z"
        ],
        type: "Stack",
        parent: "comp-K6HM4MGL0S6AH",
        rootParentType: "Stack"
    },
    "comp-K6HMAAF672VE5": {
        id: "comp-K6HMAAF672VE5",
        props: {
            children: "c",
            size: "sm",
            variant: "subtle",
            colorScheme: "gray"
        },
        children: [],
        type: "Tag",
        parent: "comp-K6HMA6UCR000W",
        rootParentType: "Tag"
    },
    "comp-K6HMAKMTZWD8Z": {
        id: "comp-K6HMAKMTZWD8Z",
        props: {
            children: "Toggle Code panel",
            color: "gray.600"
        },
        children: [],
        type: "Text",
        parent: "comp-K6HMA6UCR000W",
        rootParentType: "Text"
    },
    "comp-K6HMBS5MS8QPW": {
        id: "comp-K6HMBS5MS8QPW",
        props: {
            children: "Shortcuts",
            size: "md",
            variant: "solid",
            colorScheme: "facebook"
        },
        children: [],
        type: "Tag",
        parent: "comp-K6HM4MGL0S6AH",
        rootParentType: "Tag"
    },
    "comp-K6HMEG7J926M9": {
        id: "comp-K6HMEG7J926M9",
        props: {
            isInline: true
        },
        children: [
            "comp-K6HMEJQSG7IFT",
            "comp-K6HMGSAGN1JOU",
            "comp-K6HMEMNDIA4FF", 
        ],
        type: "Stack",
        parent: "comp-K6HM4MGL0S6AH",
        rootParentType: "Stack"
    },
    "comp-K6HMEJQSG7IFT": {
        id: "comp-K6HMEJQSG7IFT",
        props: {
            children: "cmd+y",
            size: "sm",
            variant: "subtle",
            colorScheme: "gray",
            isInline: false
        },
        children: [],
        type: "Tag",
        parent: "comp-K6HMEG7J926M9",
        rootParentType: "Tag"
    },
    "comp-K6HMEMNDIA4FF": {
        id: "comp-K6HMEMNDIA4FF",
        props: {
            children: "Redo",
            color: "gray.600"
        },
        children: [],
        type: "Text",
        parent: "comp-K6HMEG7J926M9",
        rootParentType: "Text"
    },
    "comp-K6HMGSAGN1JOU": {
        id: "comp-K6HMGSAGN1JOU",
        props: {
            children: "ctrl+y",
            size: "sm",
            variant: "subtle",
            colorScheme: "gray"
        },
        children: [],
        type: "Tag",
        parent: "comp-K6HMEG7J926M9",
        rootParentType: "Tag"
    }
};

;// CONCATENATED MODULE: ./src/templates/producthunt.ts
const productHunt = {
    root: {
        id: "root",
        parent: "root",
        type: "Box",
        children: [
            "comp-root",
            "comp-K6IB1AANA79Y6"
        ],
        props: {
            backgroundColor: "#f3f3f3"
        }
    },
    "comp-root": {
        id: "comp-root",
        props: {
            backgroundColor: "white",
            display: "flex",
            flexDirection: "row",
            alignItems: "flex-start",
            justifyContent: "space-between",
            p: "5",
            boxShadow: "sm"
        },
        children: [
            "comp-K6IAUUX80CXD6",
            "comp-K6IAWV0WFDNW7"
        ],
        type: "Box",
        parent: "root",
        rootParentType: "Box"
    },
    "comp-K6IAR7ZINSAGW": {
        id: "comp-K6IAR7ZINSAGW",
        props: {
            children: "P",
            color: "white",
            fontSize: "3xl"
        },
        children: [],
        type: "Text",
        parent: "comp-K6IAQM3L5NR7W",
        rootParentType: "Text"
    },
    "comp-K6IASJJIS6V77": {
        id: "comp-K6IASJJIS6V77",
        props: {
            size: "md",
            name: "P",
            fontSize: "3xl",
            backgroundColor: "orange.500"
        },
        children: [],
        type: "Avatar",
        parent: "comp-K6IAUUX80CXD6",
        rootParentType: "Avatar"
    },
    "comp-K6IATGONJ9KDR": {
        children: [],
        type: "InputLeftAddon",
        parent: "comp-K6IATGON2EINZ",
        id: "comp-K6IATGONJ9KDR",
        props: {
            children: "Emai"
        },
        rootParentType: "Input"
    },
    "comp-K6IATGONWXKQC": {
        children: [],
        type: "Input",
        parent: "comp-K6IATGON2EINZ",
        id: "comp-K6IATGONWXKQC",
        props: {
            size: "md",
            as: "input",
            variant: "outline",
            width: "100%",
            focusBorderColor: "blue.500",
            errorBorderColor: "red.500"
        },
        rootParentType: "Input"
    },
    "comp-K6IATGON4BXKS": {
        children: [
            "comp-K6IATGOOHID42"
        ],
        type: "InputRightElement",
        parent: "comp-K6IATGON2EINZ",
        id: "comp-K6IATGON4BXKS",
        props: {},
        rootParentType: "Input"
    },
    "comp-K6IATGOOHID42": {
        children: [],
        type: "Icon",
        parent: "comp-K6IATGON4BXKS",
        id: "comp-K6IATGOOHID42",
        props: {
            icon: "EmailIcon"
        },
        rootParentType: "Input"
    },
    "comp-K6IATQU9VOYJ0": {
        id: "comp-K6IATQU9VOYJ0",
        props: {
            display: "block",
            flexDirection: "column",
            alignItems: "flex-start",
            justifyContent: "flex-start"
        },
        children: [
            "comp-K6IATS4IZ7KD8"
        ],
        type: "InputLeftElement",
        parent: "comp-K6IATKWZ5I33A",
        rootParentType: "Input"
    },
    "comp-K6IATS4IZ7KD8": {
        id: "comp-K6IATS4IZ7KD8",
        props: {
            size: "md",
            as: "input",
            variant: "outline",
            width: "100%",
            focusBorderColor: "blue.500",
            errorBorderColor: "red.500"
        },
        children: [],
        type: "Input",
        parent: "comp-K6IATQU9VOYJ0",
        rootParentType: "Input"
    },
    "comp-K6IAUUX80CXD6": {
        id: "comp-K6IAUUX80CXD6",
        props: {
            isInline: true,
            isReversed: false,
            alignItems: "center",
            spacing: "3"
        },
        children: [
            "comp-K6IASJJIS6V77",
            "comp-K6IAV6E1J71L7",
            "comp-K6IAVUTA4NRKO",
            "comp-K6IAVYIJ6HPB2",
            "comp-K6IAW325BUPFG", 
        ],
        type: "Stack",
        parent: "comp-root",
        rootParentType: "Stack"
    },
    "comp-K6IAV6E1J71L7": {
        id: "comp-K6IAV6E1J71L7",
        props: {
            size: "md",
            as: "input",
            variant: "outline",
            width: "100%",
            focusBorderColor: "blue.500",
            errorBorderColor: "red.500",
            placeholder: "Discover your next favorite thing."
        },
        children: [],
        type: "Input",
        parent: "comp-K6IAUUX80CXD6",
        rootParentType: "Input"
    },
    "comp-K6IAVUTA4NRKO": {
        id: "comp-K6IAVUTA4NRKO",
        props: {
            children: "Deals",
            color: "gray.500"
        },
        children: [],
        type: "Link",
        parent: "comp-K6IAUUX80CXD6",
        rootParentType: "Link"
    },
    "comp-K6IAVYIJ6HPB2": {
        id: "comp-K6IAVYIJ6HPB2",
        props: {
            children: "Jobs",
            color: "gray.500"
        },
        children: [],
        type: "Link",
        parent: "comp-K6IAUUX80CXD6",
        rootParentType: "Link"
    },
    "comp-K6IAW325BUPFG": {
        id: "comp-K6IAW325BUPFG",
        props: {
            children: "Makers",
            color: "gray.500"
        },
        children: [],
        type: "Link",
        parent: "comp-K6IAUUX80CXD6",
        rootParentType: "Link"
    },
    "comp-K6IAWV0WFDNW7": {
        id: "comp-K6IAWV0WFDNW7",
        props: {},
        children: [
            "comp-K6IAX6IXQ7CAC"
        ],
        type: "Stack",
        parent: "comp-root",
        rootParentType: "Stack"
    },
    "comp-K6IAX6IXQ7CAC": {
        id: "comp-K6IAX6IXQ7CAC",
        props: {
            size: "md",
            src: "https://pbs.twimg.com/profile_images/1227316457845018626/8-B-ZDL8_400x400.jpg"
        },
        children: [
            "comp-K6IAYZAIA7RJT"
        ],
        type: "Avatar",
        parent: "comp-K6IAWV0WFDNW7",
        rootParentType: "Avatar"
    },
    "comp-K6IAYZAIA7RJT": {
        id: "comp-K6IAYZAIA7RJT",
        props: {
            bg: "green.500",
            size: "1.25em",
            borderColor: "white"
        },
        children: [],
        type: "AvatarBadge",
        parent: "comp-K6IAX6IXQ7CAC",
        rootParentType: "Avatar"
    },
    "comp-K6IB0ZX2RFMWK": {
        id: "comp-K6IB0ZX2RFMWK",
        props: {
            width: "lg"
        },
        children: [
            "comp-K6IB1HE13Y7BO",
            "comp-K6IB3I12GRYPN"
        ],
        type: "Stack",
        parent: "comp-K6IB1AANA79Y6",
        rootParentType: "Stack"
    },
    "comp-K6IB1AANA79Y6": {
        id: "comp-K6IB1AANA79Y6",
        props: {
            display: "flex",
            flexDirection: "column",
            alignItems: "flex-start",
            justifyContent: "flex-start",
            mt: "",
            p: "10"
        },
        children: [
            "comp-K6IB0ZX2RFMWK"
        ],
        type: "Flex",
        parent: "root",
        rootParentType: "Flex"
    },
    "comp-K6IB1HE13Y7BO": {
        id: "comp-K6IB1HE13Y7BO",
        props: {
            size: "lg",
            as: "h2",
            lineHeight: "shorter",
            fontWeight: "bold",
            fontFamily: "heading",
            children: "Today"
        },
        children: [],
        type: "Heading",
        parent: "comp-K6IB0ZX2RFMWK",
        rootParentType: "Heading"
    },
    "comp-K6IB3I12GRYPN": {
        id: "comp-K6IB3I12GRYPN",
        props: {
            backgroundColor: "white",
            border: "",
            borderRadius: "lg",
            p: "5"
        },
        children: [
            "comp-K6IB42UQBXOB8"
        ],
        type: "Stack",
        parent: "comp-K6IB0ZX2RFMWK",
        rootParentType: "Stack"
    },
    "comp-K6IB42UQBXOB8": {
        id: "comp-K6IB42UQBXOB8",
        props: {
            isInline: true,
            spacing: "2",
            alignItems: "center"
        },
        children: [
            "comp-K6IB45QVR3QMY",
            "comp-K6IB6HDI4V5B0"
        ],
        type: "Stack",
        parent: "comp-K6IB3I12GRYPN",
        rootParentType: "Stack"
    },
    "comp-K6IB45QVR3QMY": {
        id: "comp-K6IB45QVR3QMY",
        props: {
            height: "80px",
            width: "80px",
            fallbackSrc: "https://via.placeholder.com/150",
            src: "https://user-images.githubusercontent.com/1102595/74273767-41168880-4d11-11ea-8f7f-3fb7a02624ea.gif",
            mr: "2"
        },
        children: [],
        type: "Image",
        parent: "comp-K6IB42UQBXOB8",
        rootParentType: "Image"
    },
    "comp-K6IB6HDI4V5B0": {
        id: "comp-K6IB6HDI4V5B0",
        props: {
            spacing: "0"
        },
        children: [
            "comp-K6IB6NC6WYM4M",
            "comp-K6IB7CDZP06DC",
            "comp-K6IB9PY4ED4M3", 
        ],
        type: "Stack",
        parent: "comp-K6IB42UQBXOB8",
        rootParentType: "Stack"
    },
    "comp-K6IB6NC6WYM4M": {
        id: "comp-K6IB6NC6WYM4M",
        props: {
            children: "Open Chakra",
            fontSize: "lg",
            color: "gray.700"
        },
        children: [],
        type: "Text",
        parent: "comp-K6IB6HDI4V5B0",
        rootParentType: "Text"
    },
    "comp-K6IB7CDZP06DC": {
        id: "comp-K6IB7CDZP06DC",
        props: {
            children: "React visual editor: create UI with ease!",
            fontSize: "sm",
            color: "blackAlpha.700"
        },
        children: [],
        type: "Text",
        parent: "comp-K6IB6HDI4V5B0",
        rootParentType: "Text"
    },
    "comp-K6IB9PY4ED4M3": {
        id: "comp-K6IB9PY4ED4M3",
        props: {
            max: 4,
            spacing: -3,
            size: "xs",
            p: "",
            pl: "4",
            mt: "2"
        },
        children: [
            "comp-K6IB9SZ4T5MC3",
            "comp-K6IBA48KCVG5Y",
            "comp-K6IBA7B14LO5W",
            "comp-K6IBAM0EEARD9",
            "comp-K6IBAQN0DSH33", 
        ],
        type: "AvatarGroup",
        parent: "comp-K6IB6HDI4V5B0",
        rootParentType: "Avatar"
    },
    "comp-K6IB9SZ4T5MC3": {
        id: "comp-K6IB9SZ4T5MC3",
        props: {
            size: "xs",
            name: "Ba Adrie"
        },
        children: [],
        type: "Avatar",
        parent: "comp-K6IB9PY4ED4M3",
        rootParentType: "Avatar"
    },
    "comp-K6IBA48KCVG5Y": {
        id: "comp-K6IBA48KCVG5Y",
        props: {
            size: "xs",
            name: "to tot"
        },
        children: [],
        type: "Avatar",
        parent: "comp-K6IB9PY4ED4M3",
        rootParentType: "Avatar"
    },
    "comp-K6IBA7B14LO5W": {
        id: "comp-K6IBA7B14LO5W",
        props: {
            size: "xs"
        },
        children: [],
        type: "Avatar",
        parent: "comp-K6IB9PY4ED4M3",
        rootParentType: "Avatar"
    },
    "comp-K6IBAM0EEARD9": {
        id: "comp-K6IBAM0EEARD9",
        props: {
            size: "xs"
        },
        children: [],
        type: "Avatar",
        parent: "comp-K6IB9PY4ED4M3",
        rootParentType: "Avatar"
    },
    "comp-K6IBAQN0DSH33": {
        id: "comp-K6IBAQN0DSH33",
        props: {
            size: "md"
        },
        children: [],
        type: "Avatar",
        parent: "comp-K6IB9PY4ED4M3",
        rootParentType: "Avatar"
    }
};

;// CONCATENATED MODULE: ./src/templates/secretchakra.ts
const secretchakra = {
    root: {
        id: "root",
        parent: "root",
        type: "Box",
        children: [
            "comp-root"
        ],
        props: {}
    },
    "comp-root": {
        id: "comp-root",
        props: {
            width: "100%",
            height: "100%",
            display: "flex",
            flexDirection: "column",
            color: "",
            backgroundColor: "gray.100"
        },
        children: [
            "comp-K74L6WFISOLG3",
            "comp-K74LORRCCHJDL"
        ],
        type: "Flex",
        parent: "root",
        rootParentType: "Flex"
    },
    "comp-K74L6WFISOLG3": {
        id: "comp-K74L6WFISOLG3",
        props: {
            backgroundColor: "#1a202c",
            p: "3"
        },
        children: [
            "comp-K74L811LSF53G",
            "comp-K74LBAD12N7N8",
            "comp-K74LCUBUZD53Y", 
        ],
        type: "Flex",
        parent: "comp-root",
        rootParentType: "Flex"
    },
    "comp-K74L811LSF53G": {
        id: "comp-K74L811LSF53G",
        props: {
            display: "flex",
            fontSize: "xl",
            ml: "4"
        },
        children: [
            "comp-K74L8Y2I2J5V4",
            "comp-K74L83QUJ55KZ",
            "comp-K74L8CNA98THU", 
        ],
        type: "Box",
        parent: "comp-K74L6WFISOLG3",
        rootParentType: "Box"
    },
    "comp-K74L83QUJ55KZ": {
        id: "comp-K74L83QUJ55KZ",
        props: {
            children: "secret",
            color: "white",
            fontWeight: "bold"
        },
        children: [],
        type: "Text",
        parent: "comp-K74L811LSF53G",
        rootParentType: "Text"
    },
    "comp-K74L8CNA98THU": {
        id: "comp-K74L8CNA98THU",
        props: {
            children: "chakra",
            color: "white"
        },
        children: [],
        type: "Text",
        parent: "comp-K74L811LSF53G",
        rootParentType: "Text"
    },
    "comp-K74L8Y2I2J5V4": {
        id: "comp-K74L8Y2I2J5V4",
        props: {
            icon: "MoonIcon",
            color: "whatsapp.100",
            mr: "2"
        },
        children: [],
        type: "Icon",
        parent: "comp-K74L811LSF53G",
        rootParentType: "Icon"
    },
    "comp-K74LBAD12N7N8": {
        id: "comp-K74LBAD12N7N8",
        props: {
            justifyContent: "center",
            alignItems: "center",
            ml: "10",
            mr: "4"
        },
        children: [
            "comp-K74LBPCL2U206",
            "comp-K74LBFTN7FVZR"
        ],
        type: "Flex",
        parent: "comp-K74L6WFISOLG3",
        rootParentType: "Flex"
    },
    "comp-K74LBFTN7FVZR": {
        id: "comp-K74LBFTN7FVZR",
        props: {
            color: "teal",
            isChecked: true,
            size: "sm"
        },
        children: [],
        type: "Switch",
        parent: "comp-K74LBAD12N7N8",
        rootParentType: "Switch"
    },
    "comp-K74LBPCL2U206": {
        id: "comp-K74LBPCL2U206",
        props: {
            children: "Builder mode",
            color: "white",
            fontSize: "xs",
            pr: "2"
        },
        children: [],
        type: "Text",
        parent: "comp-K74LBAD12N7N8",
        rootParentType: "Text"
    },
    "comp-K74LCUBUXNFY3": {
        id: "comp-K74LCUBUXNFY3",
        props: {
            children: "Code panel",
            color: "white",
            fontSize: "xs",
            pr: "2"
        },
        children: [],
        type: "Text",
        parent: "comp-K74LCUBUZD53Y",
        rootParentType: "Text"
    },
    "comp-K74LCUBU9LHFQ": {
        id: "comp-K74LCUBU9LHFQ",
        props: {
            color: "teal",
            isChecked: true,
            size: "sm"
        },
        children: [],
        type: "Switch",
        parent: "comp-K74LCUBUZD53Y",
        rootParentType: "Switch"
    },
    "comp-K74LCUBUZD53Y": {
        id: "comp-K74LCUBUZD53Y",
        props: {
            justifyContent: "center",
            alignItems: "center"
        },
        children: [
            "comp-K74LCUBUXNFY3",
            "comp-K74LCUBU9LHFQ"
        ],
        type: "Flex",
        parent: "comp-K74L6WFISOLG3",
        rootParentType: "Flex"
    },
    "comp-K74LFVLYTWR7H": {
        id: "comp-K74LFVLYTWR7H",
        props: {
            width: "15rem",
            backgroundColor: "#2e3748",
            m: "",
            p: "5",
            flexDirection: "column",
            height: "100%"
        },
        children: [
            "comp-K74LH4LGZPG3Q",
            "comp-K74LJ2RGGFSO8"
        ],
        type: "Flex",
        parent: "comp-K74LORRCCHJDL",
        rootParentType: "Flex"
    },
    "comp-K74LH4LGZPG3Q": {
        id: "comp-K74LH4LGZPG3Q",
        props: {
            size: "sm",
            variant: "outline",
            backgroundColor: "gray.600",
            border: "none",
            placeholder: "Search components..."
        },
        children: [],
        type: "Input",
        parent: "comp-K74LFVLYTWR7H",
        rootParentType: "Input"
    },
    "comp-K74LJ2RGGFSO8": {
        id: "comp-K74LJ2RGGFSO8",
        props: {
            mt: "5"
        },
        children: [
            "comp-K74LJQGBRXK7V",
            "comp-K74LN1I4JX3W1",
            "comp-K74LN28WQ0U7I",
            "comp-K74LNLUX27J08",
            "comp-K74LNM59R5VQ2",
            "comp-K74LNMADR9K0Q",
            "comp-K74LNMEN8KNY1", 
        ],
        type: "Stack",
        parent: "comp-K74LFVLYTWR7H",
        rootParentType: "Stack"
    },
    "comp-K74LJQGBRXK7V": {
        id: "comp-K74LJQGBRXK7V",
        props: {
            display: "flex",
            justifyContent: "flex-start",
            alignItems: "center"
        },
        children: [
            "comp-K74LJUTPCBAFB",
            "comp-K74LKHWKQF9E6"
        ],
        type: "Box",
        parent: "comp-K74LJ2RGGFSO8",
        rootParentType: "Box"
    },
    "comp-K74LJUTPCBAFB": {
        id: "comp-K74LJUTPCBAFB",
        props: {
            icon: "DragHandleIcon",
            color: "gray.300",
            fontSize: "sm",
            mr: "2"
        },
        children: [],
        type: "Icon",
        parent: "comp-K74LJQGBRXK7V",
        rootParentType: "Icon"
    },
    "comp-K74LKHWKQF9E6": {
        id: "comp-K74LKHWKQF9E6",
        props: {
            children: "Box",
            fontSize: "sm",
            color: "gray.300"
        },
        children: [],
        type: "Text",
        parent: "comp-K74LJQGBRXK7V",
        rootParentType: "Text"
    },
    "comp-K74LN1I49Q2D6": {
        id: "comp-K74LN1I49Q2D6",
        props: {
            icon: "DragHandleIcon",
            color: "gray.300",
            fontSize: "sm",
            mr: "2"
        },
        children: [],
        type: "Icon",
        parent: "comp-K74LN1I4JX3W1",
        rootParentType: "Icon"
    },
    "comp-K74LN1I4K6K6U": {
        id: "comp-K74LN1I4K6K6U",
        props: {
            children: "Textarea",
            fontSize: "sm",
            color: "gray.300"
        },
        children: [],
        type: "Text",
        parent: "comp-K74LN1I4JX3W1",
        rootParentType: "Text"
    },
    "comp-K74LN1I4JX3W1": {
        id: "comp-K74LN1I4JX3W1",
        props: {
            display: "flex",
            justifyContent: "flex-start",
            alignItems: "center"
        },
        children: [
            "comp-K74LN1I49Q2D6",
            "comp-K74LN1I4K6K6U"
        ],
        type: "Box",
        parent: "comp-K74LJ2RGGFSO8",
        rootParentType: "Box"
    },
    "comp-K74LN28W6SFUY": {
        id: "comp-K74LN28W6SFUY",
        props: {
            icon: "DragHandleIcon",
            color: "gray.300",
            fontSize: "sm",
            mr: "2"
        },
        children: [],
        type: "Icon",
        parent: "comp-K74LN28WQ0U7I",
        rootParentType: "Icon"
    },
    "comp-K74LN28WJ5IBP": {
        id: "comp-K74LN28WJ5IBP",
        props: {
            children: "Avatar",
            fontSize: "sm",
            color: "gray.300"
        },
        children: [],
        type: "Text",
        parent: "comp-K74LN28WQ0U7I",
        rootParentType: "Text"
    },
    "comp-K74LN28WQ0U7I": {
        id: "comp-K74LN28WQ0U7I",
        props: {
            display: "flex",
            justifyContent: "flex-start",
            alignItems: "center"
        },
        children: [
            "comp-K74LN28W6SFUY",
            "comp-K74LN28WJ5IBP"
        ],
        type: "Box",
        parent: "comp-K74LJ2RGGFSO8",
        rootParentType: "Box"
    },
    "comp-K74LNLUXPHO6M": {
        id: "comp-K74LNLUXPHO6M",
        props: {
            icon: "DragHandleIcon",
            color: "gray.300",
            fontSize: "sm",
            mr: "2"
        },
        children: [],
        type: "Icon",
        parent: "comp-K74LNLUX27J08",
        rootParentType: "Icon"
    },
    "comp-K74LNLUX7SD0H": {
        id: "comp-K74LNLUX7SD0H",
        props: {
            children: "Avatar",
            fontSize: "sm",
            color: "gray.300"
        },
        children: [],
        type: "Text",
        parent: "comp-K74LNLUX27J08",
        rootParentType: "Text"
    },
    "comp-K74LNLUX27J08": {
        id: "comp-K74LNLUX27J08",
        props: {
            display: "flex",
            justifyContent: "flex-start",
            alignItems: "center"
        },
        children: [
            "comp-K74LNLUXPHO6M",
            "comp-K74LNLUX7SD0H"
        ],
        type: "Box",
        parent: "comp-K74LJ2RGGFSO8",
        rootParentType: "Box"
    },
    "comp-K74LNM597JAOI": {
        id: "comp-K74LNM597JAOI",
        props: {
            icon: "DragHandleIcon",
            color: "gray.300",
            fontSize: "sm",
            mr: "2"
        },
        children: [],
        type: "Icon",
        parent: "comp-K74LNM59R5VQ2",
        rootParentType: "Icon"
    },
    "comp-K74LNM59RM6C2": {
        id: "comp-K74LNM59RM6C2",
        props: {
            children: "Badge",
            fontSize: "sm",
            color: "gray.300"
        },
        children: [],
        type: "Text",
        parent: "comp-K74LNM59R5VQ2",
        rootParentType: "Text"
    },
    "comp-K74LNM59R5VQ2": {
        id: "comp-K74LNM59R5VQ2",
        props: {
            display: "flex",
            justifyContent: "flex-start",
            alignItems: "center"
        },
        children: [
            "comp-K74LNM597JAOI",
            "comp-K74LNM59RM6C2"
        ],
        type: "Box",
        parent: "comp-K74LJ2RGGFSO8",
        rootParentType: "Box"
    },
    "comp-K74LNMAD8I86G": {
        id: "comp-K74LNMAD8I86G",
        props: {
            icon: "DragHandleIcon",
            color: "gray.300",
            fontSize: "sm",
            mr: "2"
        },
        children: [],
        type: "Icon",
        parent: "comp-K74LNMADR9K0Q",
        rootParentType: "Icon"
    },
    "comp-K74LNMAD7BSAA": {
        id: "comp-K74LNMAD7BSAA",
        props: {
            children: "Tag",
            fontSize: "sm",
            color: "gray.300"
        },
        children: [],
        type: "Text",
        parent: "comp-K74LNMADR9K0Q",
        rootParentType: "Text"
    },
    "comp-K74LNMADR9K0Q": {
        id: "comp-K74LNMADR9K0Q",
        props: {
            display: "flex",
            justifyContent: "flex-start",
            alignItems: "center"
        },
        children: [
            "comp-K74LNMAD8I86G",
            "comp-K74LNMAD7BSAA"
        ],
        type: "Box",
        parent: "comp-K74LJ2RGGFSO8",
        rootParentType: "Box"
    },
    "comp-K74LNMENCU4KP": {
        id: "comp-K74LNMENCU4KP",
        props: {
            icon: "DragHandleIcon",
            color: "gray.300",
            fontSize: "sm",
            mr: "2"
        },
        children: [],
        type: "Icon",
        parent: "comp-K74LNMEN8KNY1",
        rootParentType: "Icon"
    },
    "comp-K74LNMENV2U06": {
        id: "comp-K74LNMENV2U06",
        props: {
            children: "Chekbox",
            fontSize: "sm",
            color: "gray.300"
        },
        children: [],
        type: "Text",
        parent: "comp-K74LNMEN8KNY1",
        rootParentType: "Text"
    },
    "comp-K74LNMEN8KNY1": {
        id: "comp-K74LNMEN8KNY1",
        props: {
            display: "flex",
            justifyContent: "flex-start",
            alignItems: "center"
        },
        children: [
            "comp-K74LNMENCU4KP",
            "comp-K74LNMENV2U06"
        ],
        type: "Box",
        parent: "comp-K74LJ2RGGFSO8",
        rootParentType: "Box"
    },
    "comp-K74LORRCCHJDL": {
        id: "comp-K74LORRCCHJDL",
        props: {
            height: "100%"
        },
        children: [
            "comp-K74LFVLYTWR7H",
            "comp-K74LPAIMR0ECA",
            "comp-K74LPCLIHYI6L", 
        ],
        type: "Flex",
        parent: "comp-root",
        rootParentType: "Flex"
    },
    "comp-K74LPAIMR0ECA": {
        id: "comp-K74LPAIMR0ECA",
        props: {
            width: "100%",
            height: "100%",
            p: "5"
        },
        children: [
            "comp-K74M9CCGRSDT1"
        ],
        type: "Flex",
        parent: "comp-K74LORRCCHJDL",
        rootParentType: "Flex"
    },
    "comp-K74LPCLIHYI6L": {
        id: "comp-K74LPCLIHYI6L",
        props: {
            width: "17rem",
            height: "100%",
            backgroundColor: "white",
            justifyContent: "flex-start",
            flexDirection: "column"
        },
        children: [
            "comp-K74LYYQF91099",
            "comp-K74M27D1Q37CK",
            "comp-K74M4AXG5WJSX",
            "comp-K74M7L09GZDX4",
            "comp-K74M7RPHLYYCJ", 
        ],
        type: "Flex",
        parent: "comp-K74LORRCCHJDL",
        rootParentType: "Flex"
    },
    "comp-K74LYYQF91099": {
        id: "comp-K74LYYQF91099",
        props: {
            bg: "yellow.100",
            p: "2",
            boxShadow: "sm"
        },
        children: [
            "comp-K74LZHHZT6RVX"
        ],
        type: "Box",
        parent: "comp-K74LPCLIHYI6L",
        rootParentType: "Box"
    },
    "comp-K74LZHHZT6RVX": {
        id: "comp-K74LZHHZT6RVX",
        props: {
            children: "SimpleGrid",
            color: "yellow.800",
            fontWeight: "bold"
        },
        children: [],
        type: "Text",
        parent: "comp-K74LYYQF91099",
        rootParentType: "Text"
    },
    "comp-K74M27D1Q37CK": {
        id: "comp-K74M27D1Q37CK",
        props: {
            justifyContent: "flex-end",
            m: "",
            mt: "2"
        },
        children: [
            "comp-K74M2CH7IR4IT",
            "comp-K74M2TSIDQKT0",
            "comp-K74M2U4X3SQZX", 
        ],
        type: "Flex",
        parent: "comp-K74LPCLIHYI6L",
        rootParentType: "Flex"
    },
    "comp-K74M2CH7IR4IT": {
        id: "comp-K74M2CH7IR4IT",
        props: {
            "aria-label": "icon",
            icon: "CopyIcon",
            size: "xs",
            variant: "ghost",
            colorScheme: "gray"
        },
        children: [],
        type: "IconButton",
        parent: "comp-K74M27D1Q37CK",
        rootParentType: "IconButton"
    },
    "comp-K74M2TSIDQKT0": {
        id: "comp-K74M2TSIDQKT0",
        props: {
            "aria-label": "icon",
            icon: "DeleteIcon",
            size: "xs",
            variant: "ghost",
            colorScheme: "gray"
        },
        children: [],
        type: "IconButton",
        parent: "comp-K74M27D1Q37CK",
        rootParentType: "IconButton"
    },
    "comp-K74M2U4X3SQZX": {
        id: "comp-K74M2U4X3SQZX",
        props: {
            "aria-label": "icon",
            icon: "RepeatIcon",
            size: "xs",
            variant: "ghost",
            colorScheme: "gray"
        },
        children: [],
        type: "IconButton",
        parent: "comp-K74M27D1Q37CK",
        rootParentType: "IconButton"
    },
    "comp-K74M4AXG5WJSX": {
        id: "comp-K74M4AXG5WJSX",
        props: {
            columns: 2,
            spacingX: 1,
            spacingY: 1,
            p: "1",
            pl: "2",
            pr: ""
        },
        children: [
            "comp-K74M4I0N0ZGMZ",
            "comp-K74M4LQNKWGCQ"
        ],
        type: "SimpleGrid",
        parent: "comp-K74LPCLIHYI6L",
        rootParentType: "SimpleGrid"
    },
    "comp-K74M4I0N0ZGMZ": {
        id: "comp-K74M4I0N0ZGMZ",
        props: {
            children: "Columns",
            fontSize: "xs",
            display: "flex",
            justifyContent: "flex-start",
            alignItems: "center",
            color: "gray.500"
        },
        children: [],
        type: "Text",
        parent: "comp-K74M4AXG5WJSX",
        rootParentType: "Text"
    },
    "comp-K74M4LQNKWGCQ": {
        id: "comp-K74M4LQNKWGCQ",
        props: {
            size: "sm"
        },
        children: [],
        type: "Input",
        parent: "comp-K74M4AXG5WJSX",
        rootParentType: "Input"
    },
    "comp-K74M7L09GCMEA": {
        id: "comp-K74M7L09GCMEA",
        props: {
            children: "Spacing X",
            fontSize: "xs",
            display: "flex",
            justifyContent: "flex-start",
            alignItems: "center",
            color: "gray.500"
        },
        children: [],
        type: "Text",
        parent: "comp-K74M7L09GZDX4",
        rootParentType: "Text"
    },
    "comp-K74M7L09OF9HM": {
        id: "comp-K74M7L09OF9HM",
        props: {
            size: "sm"
        },
        children: [],
        type: "Input",
        parent: "comp-K74M7L09GZDX4",
        rootParentType: "Input"
    },
    "comp-K74M7L09GZDX4": {
        id: "comp-K74M7L09GZDX4",
        props: {
            columns: 2,
            spacingX: 1,
            spacingY: 1,
            p: "1",
            pl: "2"
        },
        children: [
            "comp-K74M7L09GCMEA",
            "comp-K74M7L09OF9HM"
        ],
        type: "SimpleGrid",
        parent: "comp-K74LPCLIHYI6L",
        rootParentType: "SimpleGrid"
    },
    "comp-K74M7RPHZSJBU": {
        id: "comp-K74M7RPHZSJBU",
        props: {
            children: "Spacing Y",
            fontSize: "xs",
            display: "flex",
            justifyContent: "flex-start",
            alignItems: "center",
            color: "gray.500"
        },
        children: [],
        type: "Text",
        parent: "comp-K74M7RPHLYYCJ",
        rootParentType: "Text"
    },
    "comp-K74M7RPHJNL06": {
        id: "comp-K74M7RPHJNL06",
        props: {
            size: "sm"
        },
        children: [],
        type: "Input",
        parent: "comp-K74M7RPHLYYCJ",
        rootParentType: "Input"
    },
    "comp-K74M7RPHLYYCJ": {
        id: "comp-K74M7RPHLYYCJ",
        props: {
            columns: 2,
            spacingX: 1,
            spacingY: 1,
            p: "1",
            pl: "2"
        },
        children: [
            "comp-K74M7RPHZSJBU",
            "comp-K74M7RPHJNL06"
        ],
        type: "SimpleGrid",
        parent: "comp-K74LPCLIHYI6L",
        rootParentType: "SimpleGrid"
    },
    "comp-K74M9CCGNQPHP": {
        id: "comp-K74M9CCGNQPHP",
        props: {
            icon: "MoonIcon",
            color: "whatsapp.100",
            mr: "2"
        },
        children: [],
        type: "Icon",
        parent: "comp-K74M9CCGSAWAU",
        rootParentType: "Icon"
    },
    "comp-K74M9CCGBL195": {
        id: "comp-K74M9CCGBL195",
        props: {
            children: "secret",
            color: "white",
            fontWeight: "bold"
        },
        children: [],
        type: "Text",
        parent: "comp-K74M9CCGSAWAU",
        rootParentType: "Text"
    },
    "comp-K74M9CCGVYHML": {
        id: "comp-K74M9CCGVYHML",
        props: {
            children: "chakra",
            color: "white"
        },
        children: [],
        type: "Text",
        parent: "comp-K74M9CCGSAWAU",
        rootParentType: "Text"
    },
    "comp-K74M9CCGSAWAU": {
        id: "comp-K74M9CCGSAWAU",
        props: {
            display: "flex",
            fontSize: "xl",
            ml: "4"
        },
        children: [
            "comp-K74M9CCGNQPHP",
            "comp-K74M9CCGBL195",
            "comp-K74M9CCGVYHML", 
        ],
        type: "Box",
        parent: "comp-K74M9CCGUBSH1",
        rootParentType: "Box"
    },
    "comp-K74M9CCGDFLWX": {
        id: "comp-K74M9CCGDFLWX",
        props: {
            children: "Builder mode",
            color: "white",
            fontSize: "xs",
            pr: "2"
        },
        children: [],
        type: "Text",
        parent: "comp-K74M9CCGPPQ74",
        rootParentType: "Text"
    },
    "comp-K74M9CCGM8KTG": {
        id: "comp-K74M9CCGM8KTG",
        props: {
            color: "teal",
            isChecked: true,
            size: "sm"
        },
        children: [],
        type: "Switch",
        parent: "comp-K74M9CCGPPQ74",
        rootParentType: "Switch"
    },
    "comp-K74M9CCGPPQ74": {
        id: "comp-K74M9CCGPPQ74",
        props: {
            justifyContent: "center",
            alignItems: "center",
            ml: "10",
            mr: "4"
        },
        children: [
            "comp-K74M9CCGDFLWX",
            "comp-K74M9CCGM8KTG"
        ],
        type: "Flex",
        parent: "comp-K74M9CCGUBSH1",
        rootParentType: "Flex"
    },
    "comp-K74M9CCGIEWKT": {
        id: "comp-K74M9CCGIEWKT",
        props: {
            children: "Code panel",
            color: "white",
            fontSize: "xs",
            pr: "2"
        },
        children: [],
        type: "Text",
        parent: "comp-K74M9CCGWWDO1",
        rootParentType: "Text"
    },
    "comp-K74M9CCGNK2Z1": {
        id: "comp-K74M9CCGNK2Z1",
        props: {
            color: "teal",
            isChecked: true,
            size: "sm"
        },
        children: [],
        type: "Switch",
        parent: "comp-K74M9CCGWWDO1",
        rootParentType: "Switch"
    },
    "comp-K74M9CCGWWDO1": {
        id: "comp-K74M9CCGWWDO1",
        props: {
            justifyContent: "center",
            alignItems: "center"
        },
        children: [
            "comp-K74M9CCGIEWKT",
            "comp-K74M9CCGNK2Z1"
        ],
        type: "Flex",
        parent: "comp-K74M9CCGUBSH1",
        rootParentType: "Flex"
    },
    "comp-K74M9CCGUBSH1": {
        id: "comp-K74M9CCGUBSH1",
        props: {
            backgroundColor: "#1a202c",
            p: "3"
        },
        children: [
            "comp-K74M9CCGSAWAU",
            "comp-K74M9CCGPPQ74",
            "comp-K74M9CCGWWDO1", 
        ],
        type: "Flex",
        parent: "comp-K74M9CCGRSDT1",
        rootParentType: "Flex"
    },
    "comp-K74M9CCGGZE9Q": {
        id: "comp-K74M9CCGGZE9Q",
        props: {
            icon: "DragHandleIcon",
            color: "gray.300",
            fontSize: "sm",
            mr: "2"
        },
        children: [],
        type: "Icon",
        parent: "comp-K74M9CCGE9N4R",
        rootParentType: "Icon"
    },
    "comp-K74M9CCG5Q2OR": {
        id: "comp-K74M9CCG5Q2OR",
        props: {
            children: "Box",
            fontSize: "sm",
            color: "gray.300"
        },
        children: [],
        type: "Text",
        parent: "comp-K74M9CCGE9N4R",
        rootParentType: "Text"
    },
    "comp-K74M9CCGE9N4R": {
        id: "comp-K74M9CCGE9N4R",
        props: {
            display: "flex",
            justifyContent: "flex-start",
            alignItems: "center"
        },
        children: [
            "comp-K74M9CCGGZE9Q",
            "comp-K74M9CCG5Q2OR"
        ],
        type: "Box",
        parent: "comp-K74M9CCG9EXJZ",
        rootParentType: "Box"
    },
    "comp-K74M9CCG0S0RV": {
        id: "comp-K74M9CCG0S0RV",
        props: {
            icon: "DragHandleIcon",
            color: "gray.300",
            fontSize: "sm",
            mr: "2"
        },
        children: [],
        type: "Icon",
        parent: "comp-K74M9CCGCUIE7",
        rootParentType: "Icon"
    },
    "comp-K74M9CCGT6O9V": {
        id: "comp-K74M9CCGT6O9V",
        props: {
            children: "Textarea",
            fontSize: "sm",
            color: "gray.300"
        },
        children: [],
        type: "Text",
        parent: "comp-K74M9CCGCUIE7",
        rootParentType: "Text"
    },
    "comp-K74M9CCGCUIE7": {
        id: "comp-K74M9CCGCUIE7",
        props: {
            display: "flex",
            justifyContent: "flex-start",
            alignItems: "center"
        },
        children: [
            "comp-K74M9CCG0S0RV",
            "comp-K74M9CCGT6O9V"
        ],
        type: "Box",
        parent: "comp-K74M9CCG9EXJZ",
        rootParentType: "Box"
    },
    "comp-K74M9CCGPQ7C2": {
        id: "comp-K74M9CCGPQ7C2",
        props: {
            icon: "DragHandleIcon",
            color: "gray.300",
            fontSize: "sm",
            mr: "2"
        },
        children: [],
        type: "Icon",
        parent: "comp-K74M9CCGP7TL5",
        rootParentType: "Icon"
    },
    "comp-K74M9CCG88SSV": {
        id: "comp-K74M9CCG88SSV",
        props: {
            children: "Avatar",
            fontSize: "sm",
            color: "gray.300"
        },
        children: [],
        type: "Text",
        parent: "comp-K74M9CCGP7TL5",
        rootParentType: "Text"
    },
    "comp-K74M9CCGP7TL5": {
        id: "comp-K74M9CCGP7TL5",
        props: {
            display: "flex",
            justifyContent: "flex-start",
            alignItems: "center"
        },
        children: [
            "comp-K74M9CCGPQ7C2",
            "comp-K74M9CCG88SSV"
        ],
        type: "Box",
        parent: "comp-K74M9CCG9EXJZ",
        rootParentType: "Box"
    },
    "comp-K74M9CCGEPP92": {
        id: "comp-K74M9CCGEPP92",
        props: {
            icon: "DragHandleIcon",
            color: "gray.300",
            fontSize: "sm",
            mr: "2"
        },
        children: [],
        type: "Icon",
        parent: "comp-K74M9CCGIIVIY",
        rootParentType: "Icon"
    },
    "comp-K74M9CCGWS0H5": {
        id: "comp-K74M9CCGWS0H5",
        props: {
            children: "Avatar",
            fontSize: "sm",
            color: "gray.300"
        },
        children: [],
        type: "Text",
        parent: "comp-K74M9CCGIIVIY",
        rootParentType: "Text"
    },
    "comp-K74M9CCGIIVIY": {
        id: "comp-K74M9CCGIIVIY",
        props: {
            display: "flex",
            justifyContent: "flex-start",
            alignItems: "center"
        },
        children: [
            "comp-K74M9CCGEPP92",
            "comp-K74M9CCGWS0H5"
        ],
        type: "Box",
        parent: "comp-K74M9CCG9EXJZ",
        rootParentType: "Box"
    },
    "comp-K74M9CCG2CWCC": {
        id: "comp-K74M9CCG2CWCC",
        props: {
            icon: "DragHandleIcon",
            color: "gray.300",
            fontSize: "sm",
            mr: "2"
        },
        children: [],
        type: "Icon",
        parent: "comp-K74M9CCGKXNSF",
        rootParentType: "Icon"
    },
    "comp-K74M9CCGKMT3N": {
        id: "comp-K74M9CCGKMT3N",
        props: {
            children: "Badge",
            fontSize: "sm",
            color: "gray.300"
        },
        children: [],
        type: "Text",
        parent: "comp-K74M9CCGKXNSF",
        rootParentType: "Text"
    },
    "comp-K74M9CCGKXNSF": {
        id: "comp-K74M9CCGKXNSF",
        props: {
            display: "flex",
            justifyContent: "flex-start",
            alignItems: "center"
        },
        children: [
            "comp-K74M9CCG2CWCC",
            "comp-K74M9CCGKMT3N"
        ],
        type: "Box",
        parent: "comp-K74M9CCG9EXJZ",
        rootParentType: "Box"
    },
    "comp-K74M9CCGBHD01": {
        id: "comp-K74M9CCGBHD01",
        props: {
            icon: "DragHandleIcon",
            color: "gray.300",
            fontSize: "sm",
            mr: "2"
        },
        children: [],
        type: "Icon",
        parent: "comp-K74M9CCG7N53K",
        rootParentType: "Icon"
    },
    "comp-K74M9CCG2ROC8": {
        id: "comp-K74M9CCG2ROC8",
        props: {
            children: "Tag",
            fontSize: "sm",
            color: "gray.300"
        },
        children: [],
        type: "Text",
        parent: "comp-K74M9CCG7N53K",
        rootParentType: "Text"
    },
    "comp-K74M9CCG7N53K": {
        id: "comp-K74M9CCG7N53K",
        props: {
            display: "flex",
            justifyContent: "flex-start",
            alignItems: "center"
        },
        children: [
            "comp-K74M9CCGBHD01",
            "comp-K74M9CCG2ROC8"
        ],
        type: "Box",
        parent: "comp-K74M9CCG9EXJZ",
        rootParentType: "Box"
    },
    "comp-K74M9CCGJS0IN": {
        id: "comp-K74M9CCGJS0IN",
        props: {
            icon: "DragHandleIcon",
            color: "gray.300",
            fontSize: "sm",
            mr: "2"
        },
        children: [],
        type: "Icon",
        parent: "comp-K74M9CCGV27GO",
        rootParentType: "Icon"
    },
    "comp-K74M9CCGRFTZY": {
        id: "comp-K74M9CCGRFTZY",
        props: {
            children: "Chekbox",
            fontSize: "sm",
            color: "gray.300"
        },
        children: [],
        type: "Text",
        parent: "comp-K74M9CCGV27GO",
        rootParentType: "Text"
    },
    "comp-K74M9CCGV27GO": {
        id: "comp-K74M9CCGV27GO",
        props: {
            display: "flex",
            justifyContent: "flex-start",
            alignItems: "center"
        },
        children: [
            "comp-K74M9CCGJS0IN",
            "comp-K74M9CCGRFTZY"
        ],
        type: "Box",
        parent: "comp-K74M9CCG9EXJZ",
        rootParentType: "Box"
    },
    "comp-K74M9CCG9EXJZ": {
        id: "comp-K74M9CCG9EXJZ",
        props: {
            mt: "5"
        },
        children: [
            "comp-K74M9CCGE9N4R",
            "comp-K74M9CCGCUIE7",
            "comp-K74M9CCGP7TL5",
            "comp-K74M9CCGIIVIY",
            "comp-K74M9CCGKXNSF",
            "comp-K74M9CCG7N53K",
            "comp-K74M9CCGV27GO", 
        ],
        type: "Stack",
        parent: "comp-K74M9CCG94DEQ",
        rootParentType: "Stack"
    },
    "comp-K74M9CCG94DEQ": {
        id: "comp-K74M9CCG94DEQ",
        props: {
            width: "15rem",
            backgroundColor: "#2e3748",
            m: "",
            p: "5",
            flexDirection: "column",
            height: "100%"
        },
        children: [
            "comp-K74MDRB8N3GRS",
            "comp-K74M9CCG9EXJZ"
        ],
        type: "Flex",
        parent: "comp-K74M9CCGQDXNZ",
        rootParentType: "Flex"
    },
    "comp-K74M9CCGVB5K9": {
        id: "comp-K74M9CCGVB5K9",
        props: {
            width: "100%",
            height: "100%"
        },
        children: [],
        type: "Flex",
        parent: "comp-K74M9CCGQDXNZ",
        rootParentType: "Flex"
    },
    "comp-K74M9CCG9YO15": {
        id: "comp-K74M9CCG9YO15",
        props: {
            children: "SimpleGrid",
            color: "yellow.800",
            fontWeight: "bold"
        },
        children: [],
        type: "Text",
        parent: "comp-K74M9CCGZGAAN",
        rootParentType: "Text"
    },
    "comp-K74M9CCGZGAAN": {
        id: "comp-K74M9CCGZGAAN",
        props: {
            bg: "yellow.100",
            p: "2",
            boxShadow: "sm"
        },
        children: [
            "comp-K74M9CCG9YO15"
        ],
        type: "Box",
        parent: "comp-K74M9CCG9WW9R",
        rootParentType: "Box"
    },
    "comp-K74M9CCGSW3SU": {
        id: "comp-K74M9CCGSW3SU",
        props: {
            "aria-label": "icon",
            icon: "CopyIcon",
            size: "xs",
            variant: "ghost",
            colorScheme: "gray"
        },
        children: [],
        type: "IconButton",
        parent: "comp-K74M9CCGNMBYL",
        rootParentType: "IconButton"
    },
    "comp-K74M9CCGTKCJ7": {
        id: "comp-K74M9CCGTKCJ7",
        props: {
            "aria-label": "icon",
            icon: "DeleteIcon",
            size: "xs",
            variant: "ghost",
            colorScheme: "gray"
        },
        children: [],
        type: "IconButton",
        parent: "comp-K74M9CCGNMBYL",
        rootParentType: "IconButton"
    },
    "comp-K74M9CCGGX02O": {
        id: "comp-K74M9CCGGX02O",
        props: {
            "aria-label": "icon",
            icon: "RepeatIcon",
            size: "xs",
            variant: "ghost",
            colorScheme: "gray"
        },
        children: [],
        type: "IconButton",
        parent: "comp-K74M9CCGNMBYL",
        rootParentType: "IconButton"
    },
    "comp-K74M9CCGNMBYL": {
        id: "comp-K74M9CCGNMBYL",
        props: {
            justifyContent: "flex-end",
            m: "",
            mt: "2"
        },
        children: [
            "comp-K74M9CCGSW3SU",
            "comp-K74M9CCGTKCJ7",
            "comp-K74M9CCGGX02O", 
        ],
        type: "Flex",
        parent: "comp-K74M9CCG9WW9R",
        rootParentType: "Flex"
    },
    "comp-K74M9CCGF4AWI": {
        id: "comp-K74M9CCGF4AWI",
        props: {
            children: "Columns",
            fontSize: "xs",
            display: "flex",
            justifyContent: "flex-start",
            alignItems: "center",
            color: "gray.500"
        },
        children: [],
        type: "Text",
        parent: "comp-K74M9CCGGMJ6O",
        rootParentType: "Text"
    },
    "comp-K74M9CCGX9HAN": {
        id: "comp-K74M9CCGX9HAN",
        props: {
            size: "sm"
        },
        children: [],
        type: "Input",
        parent: "comp-K74M9CCGGMJ6O",
        rootParentType: "Input"
    },
    "comp-K74M9CCGGMJ6O": {
        id: "comp-K74M9CCGGMJ6O",
        props: {
            columns: 2,
            spacingX: 1,
            spacingY: 1,
            p: "1",
            pl: "2",
            pr: ""
        },
        children: [
            "comp-K74M9CCGF4AWI",
            "comp-K74M9CCGX9HAN"
        ],
        type: "SimpleGrid",
        parent: "comp-K74M9CCG9WW9R",
        rootParentType: "SimpleGrid"
    },
    "comp-K74M9CCGT5UYZ": {
        id: "comp-K74M9CCGT5UYZ",
        props: {
            children: "Spacing X",
            fontSize: "xs",
            display: "flex",
            justifyContent: "flex-start",
            alignItems: "center",
            color: "gray.500"
        },
        children: [],
        type: "Text",
        parent: "comp-K74M9CCGZMAHR",
        rootParentType: "Text"
    },
    "comp-K74M9CCGST1K3": {
        id: "comp-K74M9CCGST1K3",
        props: {
            size: "sm"
        },
        children: [],
        type: "Input",
        parent: "comp-K74M9CCGZMAHR",
        rootParentType: "Input"
    },
    "comp-K74M9CCGZMAHR": {
        id: "comp-K74M9CCGZMAHR",
        props: {
            columns: 2,
            spacingX: 1,
            spacingY: 1,
            p: "1",
            pl: "2"
        },
        children: [
            "comp-K74M9CCGT5UYZ",
            "comp-K74M9CCGST1K3"
        ],
        type: "SimpleGrid",
        parent: "comp-K74M9CCG9WW9R",
        rootParentType: "SimpleGrid"
    },
    "comp-K74M9CCG0N30O": {
        id: "comp-K74M9CCG0N30O",
        props: {
            children: "Spacing Y",
            fontSize: "xs",
            display: "flex",
            justifyContent: "flex-start",
            alignItems: "center",
            color: "gray.500"
        },
        children: [],
        type: "Text",
        parent: "comp-K74M9CCG6F4OJ",
        rootParentType: "Text"
    },
    "comp-K74M9CCGBJE71": {
        id: "comp-K74M9CCGBJE71",
        props: {
            size: "sm"
        },
        children: [],
        type: "Input",
        parent: "comp-K74M9CCG6F4OJ",
        rootParentType: "Input"
    },
    "comp-K74M9CCG6F4OJ": {
        id: "comp-K74M9CCG6F4OJ",
        props: {
            columns: 2,
            spacingX: 1,
            spacingY: 1,
            p: "1",
            pl: "2"
        },
        children: [
            "comp-K74M9CCG0N30O",
            "comp-K74M9CCGBJE71"
        ],
        type: "SimpleGrid",
        parent: "comp-K74M9CCG9WW9R",
        rootParentType: "SimpleGrid"
    },
    "comp-K74M9CCG9WW9R": {
        id: "comp-K74M9CCG9WW9R",
        props: {
            width: "17rem",
            height: "100%",
            backgroundColor: "white",
            justifyContent: "flex-start",
            flexDirection: "column"
        },
        children: [
            "comp-K74M9CCGZGAAN",
            "comp-K74M9CCGNMBYL",
            "comp-K74M9CCGGMJ6O",
            "comp-K74M9CCGZMAHR",
            "comp-K74M9CCG6F4OJ", 
        ],
        type: "Flex",
        parent: "comp-K74M9CCGQDXNZ",
        rootParentType: "Flex"
    },
    "comp-K74M9CCGQDXNZ": {
        id: "comp-K74M9CCGQDXNZ",
        props: {
            height: "100%"
        },
        children: [
            "comp-K74M9CCG94DEQ",
            "comp-K74M9CCGVB5K9",
            "comp-K74M9CCG9WW9R", 
        ],
        type: "Flex",
        parent: "comp-K74M9CCGRSDT1",
        rootParentType: "Flex"
    },
    "comp-K74M9CCGRSDT1": {
        id: "comp-K74M9CCGRSDT1",
        props: {
            width: "100%",
            height: "100%",
            display: "flex",
            flexDirection: "column",
            color: "",
            backgroundColor: "gray.100"
        },
        children: [
            "comp-K74M9CCGUBSH1",
            "comp-K74M9CCGQDXNZ"
        ],
        type: "Flex",
        parent: "comp-K74LPAIMR0ECA",
        rootParentType: "Flex"
    },
    "comp-K74MDRB8N3GRS": {
        id: "comp-K74MDRB8N3GRS",
        props: {
            size: "sm",
            variant: "outline",
            backgroundColor: "gray.600",
            border: "none",
            placeholder: "Search components..."
        },
        children: [],
        type: "Input",
        parent: "comp-K74M9CCG94DEQ",
        rootParentType: "Input"
    }
};

;// CONCATENATED MODULE: ./src/templates/index.ts



const templates = {
    ph: productHunt,
    onboarding: onboarding,
    secretchakra: secretchakra
};
/* harmony default export */ const src_templates = (templates);


/***/ }),

/***/ 3881:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "O": () => (/* binding */ duplicateComponent),
/* harmony export */   "v": () => (/* binding */ deleteComponent)
/* harmony export */ });
/* harmony import */ var lodash_omit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3901);
/* harmony import */ var lodash_omit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash_omit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var lodash_filter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9368);
/* harmony import */ var lodash_filter__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash_filter__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _generateId__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(427);



const duplicateComponent = (componentToClone, components)=>{
    const clonedComponents = {};
    const cloneComponent = (component)=>{
        const newid = (0,_generateId__WEBPACK_IMPORTED_MODULE_2__/* .generateId */ .O)();
        const children = component.children.map((child)=>{
            return cloneComponent(components[child]);
        });
        let newComponentName = component.componentName;
        if (newComponentName) {
            const matches = /^([a-zA-Z]*)(\d+)?$/g.exec(newComponentName);
            // Get all components with a similar name (same base component name + number suffix)
            const similarComponents = lodash_filter__WEBPACK_IMPORTED_MODULE_1___default()(components, (comp)=>!!comp.componentName?.includes(matches[1]));
            let highestNumber = 0;
            // Get the highest suffix number
            similarComponents.forEach((comp)=>{
                const nameMatches = /^([a-zA-Z]*)(\d+)?$/g.exec(comp.componentName);
                const number = nameMatches?.length === 2 ? 0 : Number(nameMatches[2]);
                if (number > highestNumber) {
                    highestNumber = number;
                }
            });
            // Use the suffix number + 1 to name our duplicated component
            newComponentName = newComponentName.replace(/^([a-zA-Z]*)(\d+)?$/g, `$1${highestNumber + 1}`);
        }
        clonedComponents[newid] = {
            ...component,
            id: newid,
            props: {
                ...component.props
            },
            children,
            componentName: newComponentName
        };
        children.forEach((child)=>{
            clonedComponents[child].parent = newid;
        });
        return newid;
    };
    const newId = cloneComponent(componentToClone);
    return {
        newId,
        clonedComponents
    };
};
const deleteComponent = (component, components)=>{
    let updatedComponents = {
        ...components
    };
    const deleteRecursive = (children, id)=>{
        children.forEach((child)=>{
            updatedComponents[child] && deleteRecursive(updatedComponents[child].children, child);
        });
        updatedComponents = lodash_omit__WEBPACK_IMPORTED_MODULE_0___default()(updatedComponents, id);
    };
    deleteRecursive(component.children, component.id);
    updatedComponents = lodash_omit__WEBPACK_IMPORTED_MODULE_0___default()(updatedComponents, component.id);
    return updatedComponents;
};


/***/ }),

/***/ 5054:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ filterActions)
/* harmony export */ });
function filterActions(action) {
    if ([
        "components/reset",
        "components/loadDemo",
        "components/resetProps",
        "components/updateProps",
        "components/addComponent",
        "components/deleteComponent",
        "components/moveComponent",
        "components/addMetaComponent",
        "components/moveSelectedComponentChildren",
        "components/duplicate", 
    ].includes(action.type)) {
        return true;
    }
    return false;
};


/***/ }),

/***/ 2453:
/***/ ((module) => {

module.exports = require("@bugsnag/js");

/***/ }),

/***/ 7736:
/***/ ((module) => {

module.exports = require("@bugsnag/plugin-react");

/***/ }),

/***/ 4513:
/***/ ((module) => {

module.exports = require("@chakra-ui/icons");

/***/ }),

/***/ 8930:
/***/ ((module) => {

module.exports = require("@chakra-ui/react");

/***/ }),

/***/ 3236:
/***/ ((module) => {

module.exports = require("@chakra-ui/theme");

/***/ }),

/***/ 9710:
/***/ ((module) => {

module.exports = require("@rematch/core");

/***/ }),

/***/ 9368:
/***/ ((module) => {

module.exports = require("lodash/filter");

/***/ }),

/***/ 2327:
/***/ ((module) => {

module.exports = require("lodash/isBoolean");

/***/ }),

/***/ 3707:
/***/ ((module) => {

module.exports = require("lodash/map");

/***/ }),

/***/ 3901:
/***/ ((module) => {

module.exports = require("lodash/omit");

/***/ }),

/***/ 5648:
/***/ ((module) => {

module.exports = require("next-redux-wrapper");

/***/ }),

/***/ 9761:
/***/ ((module) => {

module.exports = require("prettier/parser-babylon");

/***/ }),

/***/ 7413:
/***/ ((module) => {

module.exports = require("prettier/standalone");

/***/ }),

/***/ 7096:
/***/ ((module) => {

module.exports = require("prism-react-renderer");

/***/ }),

/***/ 9123:
/***/ ((module) => {

module.exports = require("prism-react-renderer/themes/nightOwl");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 7964:
/***/ ((module) => {

module.exports = require("react-dnd");

/***/ }),

/***/ 6290:
/***/ ((module) => {

module.exports = require("react-icons/fa");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 4312:
/***/ ((module) => {

module.exports = require("react-split-pane");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 6695:
/***/ ((module) => {

module.exports = require("redux");

/***/ }),

/***/ 4161:
/***/ ((module) => {

module.exports = require("redux-persist");

/***/ }),

/***/ 8936:
/***/ ((module) => {

module.exports = require("redux-persist/lib/storage");

/***/ }),

/***/ 8497:
/***/ ((module) => {

module.exports = require("redux-undo");

/***/ }),

/***/ 9810:
/***/ ((module) => {

module.exports = import("immer");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [108], () => (__webpack_exec__(2957)));
module.exports = __webpack_exports__;

})();