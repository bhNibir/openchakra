"use strict";
exports.id = 108;
exports.ids = [108];
exports.modules = {

/***/ 2445:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ editor_Editor),
  "m": () => (/* binding */ gridStyles)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "@chakra-ui/react"
var react_ = __webpack_require__(8930);
// EXTERNAL MODULE: external "react-dnd"
var external_react_dnd_ = __webpack_require__(7964);
;// CONCATENATED MODULE: ./src/utils/editor.ts
const ALERT_COMPONENTS = [
    "Alert",
    "AlertDescription",
    "AlertIcon",
    "AlertTitle", 
];
const COMPONENTS = [
    ...ALERT_COMPONENTS,
    "Avatar",
    "AvatarBadge",
    "AvatarGroup",
    "Badge",
    "Box",
    "Button",
    "Center",
    "Checkbox",
    "CircularProgress",
    "CloseButton",
    "Code",
    "Container",
    "Divider",
    "Flex",
    "FormControl",
    "FormLabel",
    "FormHelperText",
    "FormErrorMessage",
    "Grid",
    "Heading",
    "Highlight",
    "Icon",
    "IconButton",
    "Image",
    "Input",
    "InputGroup",
    "InputRightAddon",
    "InputLeftAddon",
    "Link",
    "List",
    "ListItem",
    "Progress",
    "Radio",
    "RadioGroup",
    "SimpleGrid",
    "Spinner",
    "Select",
    "Skeleton",
    "SkeletonCircle",
    "SkeletonText",
    "Stack",
    "Switch",
    "Tag",
    "Text",
    "Kbd",
    "Textarea",
    "Tab",
    "Accordion",
    "Editable",
    "AspectRatio",
    "Breadcrumb",
    "BreadcrumbItem",
    "BreadcrumbLink",
    "Menu",
    "NumberInput",
    "AccordionItem",
    "AccordionButton",
    "AccordionPanel",
    "AccordionIcon",
    "InputRightElement",
    "InputLeftElement",
    "Tab",
    "TabList",
    "TabPanel",
    "TabPanels",
    "Tabs",
    "Stat",
    "StatLabel",
    "StatNumber",
    "StatHelpText",
    "StatArrow",
    "StatGroup",
    // Allow meta components
    "AlertMeta",
    "FormControlMeta",
    "AccordionMeta",
    "ListMeta",
    "InputGroupMeta",
    "BreadcrumbMeta",
    "TabsMeta",
    "StatMeta", 
];
const AccordionWhitelist = COMPONENTS.filter((name)=>!ALERT_COMPONENTS.includes(name));
const rootComponents = COMPONENTS// Remove specific components
.filter((name)=>![
        "AlertIcon",
        "AlertDescription",
        "AlertTitle",
        "AvatarBadge",
        "AccordionButton",
        "AccordionPanel",
        "AccordionIcon",
        "BreadcrumbItem",
        "BreadcrumbLink", 
    ].includes(name));

// EXTERNAL MODULE: ./src/hooks/useDispatch.ts
var useDispatch = __webpack_require__(5690);
// EXTERNAL MODULE: ./src/utils/defaultProps.tsx
var utils_defaultProps = __webpack_require__(9737);
// EXTERNAL MODULE: ./src/utils/generateId.ts
var generateId = __webpack_require__(427);
;// CONCATENATED MODULE: ./src/core/models/composer/composer.ts


class Composer {
    components = {};
    rootComponentType = undefined;
    constructor(name){
        if (name) {
            this.rootComponentType = name;
        }
    }
    addNode = ({ type , parent ="root" , props ={} , rootParentType  })=>{
        const id = (0,generateId/* generateId */.O)();
        if (parent === "root" && !this.rootComponentType) {
            this.rootComponentType = type;
        }
        const localRootParentType = rootParentType || this.rootComponentType;
        const { form , ...defaultProps } = utils_defaultProps/* DEFAULT_PROPS */.n[type] || {};
        this.components = {
            ...this.components,
            [id]: {
                children: [],
                type,
                parent,
                id,
                props: {
                    ...defaultProps,
                    ...props
                },
                rootParentType: localRootParentType
            }
        };
        if (parent !== "root" && this.components[parent]) {
            this.components[parent].children.push(id);
        }
        return id;
    };
    getComponents() {
        return this.components;
    }
}
/* harmony default export */ const composer_composer = (Composer);

;// CONCATENATED MODULE: ./src/core/models/composer/builder.ts

const buildAlert = (parent)=>{
    const composer = new composer_composer();
    const nodeId = composer.addNode({
        type: "Alert",
        parent
    });
    composer.addNode({
        type: "AlertIcon",
        parent: nodeId
    });
    composer.addNode({
        type: "AlertTitle",
        parent: nodeId
    });
    composer.addNode({
        type: "AlertDescription",
        parent: nodeId
    });
    const components = composer.getComponents();
    return {
        components,
        root: nodeId,
        parent
    };
};
const buildBreadcrumb = (parent)=>{
    const composer = new composer_composer();
    const nodeId = composer.addNode({
        type: "Breadcrumb",
        parent
    });
    const itemId = composer.addNode({
        type: "BreadcrumbItem",
        parent: nodeId
    });
    composer.addNode({
        type: "BreadcrumbLink",
        parent: itemId
    });
    const secondItemId = composer.addNode({
        type: "BreadcrumbItem",
        parent: nodeId
    });
    composer.addNode({
        type: "BreadcrumbLink",
        parent: secondItemId
    });
    const components = composer.getComponents();
    return {
        components,
        root: nodeId,
        parent
    };
};
const buildFormControl = (parent)=>{
    const composer = new composer_composer();
    const nodeId = composer.addNode({
        type: "FormControl",
        parent
    });
    composer.addNode({
        type: "FormLabel",
        parent: nodeId
    });
    composer.addNode({
        type: "Input",
        parent: nodeId,
        rootParentType: "Input"
    });
    composer.addNode({
        type: "FormHelperText",
        parent: nodeId
    });
    composer.addNode({
        type: "FormErrorMessage",
        parent: nodeId
    });
    const components = composer.getComponents();
    return {
        components,
        root: nodeId,
        parent
    };
};
const buildAccordion = (parent)=>{
    const composer = new composer_composer("Accordion");
    const nodeId = composer.addNode({
        type: "Accordion",
        parent
    });
    const itemId = composer.addNode({
        type: "AccordionItem",
        parent: nodeId
    });
    const headerId = composer.addNode({
        type: "AccordionButton",
        parent: itemId
    });
    const panelId = composer.addNode({
        type: "AccordionPanel",
        parent: itemId
    });
    composer.addNode({
        type: "Text",
        parent: headerId,
        rootParentType: "Text"
    });
    composer.addNode({
        type: "AccordionIcon",
        parent: headerId
    });
    composer.addNode({
        type: "Text",
        parent: panelId,
        rootParentType: "Text"
    });
    const components = composer.getComponents();
    return {
        components,
        root: nodeId,
        parent
    };
};
const buildTabs = (parent)=>{
    const composer = new composer_composer("Tabs");
    const nodeId = composer.addNode({
        type: "Tabs",
        parent
    });
    const tabListId = composer.addNode({
        type: "TabList",
        parent: nodeId
    });
    const tabPanelsId = composer.addNode({
        type: "TabPanels",
        parent: nodeId
    });
    composer.addNode({
        type: "Tab",
        parent: tabListId,
        props: {
            children: "One"
        }
    });
    composer.addNode({
        type: "Tab",
        parent: tabListId,
        props: {
            children: "Two"
        }
    });
    composer.addNode({
        type: "TabPanel",
        parent: tabPanelsId,
        props: {
            children: "One !"
        }
    });
    composer.addNode({
        type: "TabPanel",
        parent: tabPanelsId,
        props: {
            children: "Two !"
        }
    });
    const components = composer.getComponents();
    return {
        components,
        root: nodeId,
        parent
    };
};
const buildStats = (parent)=>{
    const composer = new composer_composer("Stat");
    const nodeId = composer.addNode({
        type: "Stat",
        parent
    });
    composer.addNode({
        type: "StatLabel",
        parent: nodeId,
        props: {
            children: "Stat label"
        }
    });
    composer.addNode({
        type: "StatNumber",
        parent: nodeId,
        props: {
            children: "45"
        }
    });
    const helpTextId = composer.addNode({
        type: "StatHelpText",
        parent: nodeId
    });
    composer.addNode({
        type: "StatArrow",
        parent: helpTextId,
        props: {
            type: "increase"
        }
    });
    composer.addNode({
        type: "Text",
        parent: helpTextId,
        props: {
            children: "23.36%"
        }
    });
    const components = composer.getComponents();
    return {
        components,
        root: nodeId,
        parent
    };
};
const buildList = (parent)=>{
    const composer = new composer_composer("List");
    const nodeId = composer.addNode({
        type: "List",
        parent
    });
    composer.addNode({
        type: "ListItem",
        parent: nodeId
    });
    const components = composer.getComponents();
    return {
        components,
        root: nodeId,
        parent
    };
};
const buildInputGroup = (parent)=>{
    const composer = new composer_composer("Input");
    const nodeId = composer.addNode({
        type: "InputGroup",
        parent
    });
    composer.addNode({
        type: "InputLeftAddon",
        parent: nodeId,
        props: {
            children: "Email"
        }
    });
    composer.addNode({
        type: "Input",
        parent: nodeId
    });
    const elementId = composer.addNode({
        type: "InputRightElement",
        parent: nodeId
    });
    composer.addNode({
        type: "Icon",
        parent: elementId,
        props: {
            name: "email"
        }
    });
    const components = composer.getComponents();
    return {
        components,
        root: nodeId,
        parent
    };
};
const builders = {
    AlertMeta: buildAlert,
    FormControlMeta: buildFormControl,
    AccordionMeta: buildAccordion,
    ListMeta: buildList,
    InputGroupMeta: buildInputGroup,
    BreadcrumbMeta: buildBreadcrumb,
    TabsMeta: buildTabs,
    StatMeta: buildStats
};
/* harmony default export */ const builder = (builders);

;// CONCATENATED MODULE: ./src/hooks/useDropComponent.ts




const useDropComponent = (componentId, accept = rootComponents, canDrop = true)=>{
    const dispatch = (0,useDispatch/* default */.Z)();
    const [{ isOver  }, drop] = (0,external_react_dnd_.useDrop)({
        accept,
        collect: (monitor)=>({
                isOver: monitor.isOver({
                    shallow: true
                }) && monitor.canDrop()
            }),
        drop: (item, monitor)=>{
            if (!monitor.isOver()) {
                return;
            }
            if (item.isMoved) {
                dispatch.components.moveComponent({
                    parentId: componentId,
                    componentId: item.id
                });
            } else if (item.isMeta) {
                dispatch.components.addMetaComponent(builder[item.type](componentId));
            } else {
                dispatch.components.addComponent({
                    parentName: componentId,
                    type: item.type,
                    rootParentType: item.rootParentType
                });
            }
        },
        canDrop: ()=>canDrop
    });
    return {
        drop,
        isOver
    };
};

// EXTERNAL MODULE: external "react-split-pane"
var external_react_split_pane_ = __webpack_require__(4312);
var external_react_split_pane_default = /*#__PURE__*/__webpack_require__.n(external_react_split_pane_);
// EXTERNAL MODULE: external "prism-react-renderer"
var external_prism_react_renderer_ = __webpack_require__(7096);
var external_prism_react_renderer_default = /*#__PURE__*/__webpack_require__.n(external_prism_react_renderer_);
// EXTERNAL MODULE: ./src/utils/code.ts
var utils_code = __webpack_require__(8453);
// EXTERNAL MODULE: external "prism-react-renderer/themes/nightOwl"
var nightOwl_ = __webpack_require__(9123);
var nightOwl_default = /*#__PURE__*/__webpack_require__.n(nightOwl_);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: ./src/core/selectors/components.ts
var selectors_components = __webpack_require__(4179);
;// CONCATENATED MODULE: ./src/components/CodePanel.tsx








const CodePanel = ()=>{
    const components = (0,external_react_redux_.useSelector)(selectors_components/* getComponents */.OQ);
    const { 0: code , 1: setCode  } = (0,external_react_.useState)(undefined);
    (0,external_react_.useEffect)(()=>{
        const getCode = async ()=>{
            const code = await (0,utils_code/* generateCode */.bB)(components);
            setCode(code);
        };
        getCode();
    }, [
        components
    ]);
    const { onCopy , hasCopied  } = (0,react_.useClipboard)(code);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Box, {
        zIndex: 5,
        p: 4,
        fontSize: "sm",
        backgroundColor: "#011627",
        overflow: "auto",
        position: "absolute",
        top: 0,
        bottom: 0,
        left: 0,
        right: 0,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(react_.Button, {
                onClick: onCopy,
                size: "sm",
                position: "absolute",
                textTransform: "uppercase",
                colorScheme: "teal",
                fontSize: "xs",
                height: "24px",
                top: 4,
                right: "1.25em",
                children: hasCopied ? "copied" : "copy"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((external_prism_react_renderer_default()), {
                ...external_prism_react_renderer_.defaultProps,
                theme: (nightOwl_default()),
                code: code || "// Formatting code… please wait ✨",
                language: "jsx",
                children: ({ className , style , tokens , getLineProps , getTokenProps  })=>/*#__PURE__*/ jsx_runtime_.jsx("pre", {
                        className: className,
                        style: style,
                        children: tokens.map((line, i)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                ...getLineProps({
                                    line,
                                    key: i
                                }),
                                children: line.map((token, key)=>/*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        ...getTokenProps({
                                            token,
                                            key
                                        })
                                    }, key))
                            }, i))
                    })
            })
        ]
    });
};
/* harmony default export */ const components_CodePanel = (/*#__PURE__*/(0,external_react_.memo)(CodePanel));

// EXTERNAL MODULE: ./src/core/selectors/app.ts
var app = __webpack_require__(4203);
;// CONCATENATED MODULE: ./src/hooks/useInteractive.ts






const useInteractive = (component, enableVisualHelper = false, withoutComponentProps = false)=>{
    const dispatch = (0,useDispatch/* default */.Z)();
    const showLayout = (0,external_react_redux_.useSelector)(app/* getShowLayout */.tk);
    const isComponentSelected = (0,external_react_redux_.useSelector)((0,selectors_components/* getIsSelectedComponent */._y)(component.id));
    const isHovered = (0,external_react_redux_.useSelector)((0,selectors_components/* getIsHovered */.mI)(component.id));
    const focusInput = (0,external_react_redux_.useSelector)((0,app/* getFocusedComponent */.qs)(component.id));
    const [, drag] = (0,external_react_dnd_.useDrag)({
        item: {
            id: component.id,
            type: component.type,
            isMoved: true
        }
    });
    const ref = (0,external_react_.useRef)(null);
    let props = {
        ...withoutComponentProps ? {} : component.props,
        onMouseOver: (event)=>{
            event.stopPropagation();
            dispatch.components.hover(component.id);
        },
        onMouseOut: ()=>{
            dispatch.components.unhover();
        },
        onClick: (event)=>{
            event.preventDefault();
            event.stopPropagation();
            dispatch.components.select(component.id);
        },
        onDoubleClick: (event)=>{
            event.preventDefault();
            event.stopPropagation();
            if (focusInput === false) {
                dispatch.app.toggleInputText();
            }
        }
    };
    if (showLayout && enableVisualHelper) {
        props = {
            ...props,
            border: `1px dashed #718096`,
            padding: props.p || props.padding ? props.p || props.padding : 4
        };
    }
    if (isHovered || isComponentSelected) {
        props = {
            ...props,
            boxShadow: `${focusInput ? "#ffc4c7" : "#4FD1C5"} 0px 0px 0px 2px inset`
        };
    }
    return {
        props,
        ref: drag(ref),
        drag
    };
};

;// CONCATENATED MODULE: ./src/components/editor/previews/AlertPreview.tsx






const AlertPreview = ({ component  })=>{
    const acceptedTypes = [
        "AlertIcon",
        "AlertTitle",
        "AlertDescription", 
    ];
    const { props , ref  } = useInteractive(component, false);
    const { drop , isOver  } = useDropComponent(component.id, acceptedTypes);
    let boxProps = {};
    if (isOver) {
        props.bg = "teal.50";
    }
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
        ref: drop(ref),
        ...boxProps,
        children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Alert, {
            ...props,
            children: component.children.map((key)=>/*#__PURE__*/ jsx_runtime_.jsx(editor_ComponentPreview, {
                    componentName: key
                }, key))
        })
    });
};
/* harmony default export */ const previews_AlertPreview = (AlertPreview);

;// CONCATENATED MODULE: ./src/components/editor/previews/AvatarPreview.tsx








const AvatarPreview = ({ component , spacing , index  })=>{
    const { drop , isOver  } = useDropComponent(component.id, [
        "AvatarBadge"
    ]);
    const { props , ref  } = useInteractive(component);
    let boxProps = {
        display: "inline-block",
        zIndex: index ? 20 - index : null
    };
    props.p = 0;
    if (isOver) {
        props.bg = "teal.50";
    }
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
        ref: drop(ref),
        ...boxProps,
        children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Avatar, {
            ml: index === 0 ? 0 : spacing,
            ...props,
            children: component.children.map((key)=>/*#__PURE__*/ jsx_runtime_.jsx(editor_ComponentPreview, {
                    componentName: key
                }, key))
        })
    });
};
const AvatarGroupPreview = ({ component  })=>{
    const { props , ref  } = useInteractive(component, true);
    const { drop , isOver  } = useDropComponent(component.id, [
        "Avatar"
    ]);
    const components = (0,external_react_redux_.useSelector)(selectors_components/* getComponents */.OQ);
    let boxProps = {
        display: "inline"
    };
    if (isOver) {
        props.bg = "teal.50";
    }
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
        ref: drop(ref),
        ...boxProps,
        children: /*#__PURE__*/ jsx_runtime_.jsx(react_.AvatarGroup, {
            ...props,
            children: component.children.map((key, i)=>/*#__PURE__*/ jsx_runtime_.jsx(AvatarPreview, {
                    index: i + 1,
                    spacing: props.spacing,
                    component: components[key]
                }, key))
        })
    });
};
const AvatarBadgePreview = ({ component  })=>{
    const { props , ref  } = useInteractive(component);
    let boxProps = {};
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
        ...boxProps,
        ref: ref,
        children: /*#__PURE__*/ jsx_runtime_.jsx(react_.AvatarBadge, {
            ...props
        })
    });
};
/* harmony default export */ const previews_AvatarPreview = (AvatarPreview);

;// CONCATENATED MODULE: ./src/components/editor/previews/AccordionPreview.tsx







const acceptedTypes = [
    "AccordionItem"
];
const AccordionPreview = ({ component  })=>{
    const { props , ref  } = useInteractive(component, true);
    const { drop , isOver  } = useDropComponent(component.id, acceptedTypes);
    let boxProps = {};
    if (isOver) {
        props.bg = "teal.50";
    }
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
        ref: drop(ref),
        ...boxProps,
        children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Accordion, {
            ...props,
            children: component.children.map((key)=>/*#__PURE__*/ jsx_runtime_.jsx(editor_ComponentPreview, {
                    componentName: key
                }, key))
        })
    });
};
const AccordionButtonPreview = ({ component  })=>{
    const { props , ref  } = useInteractive(component, true);
    const { drop , isOver  } = useDropComponent(component.id, AccordionWhitelist);
    if (isOver) {
        props.bg = "teal.50";
    }
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.AccordionButton, {
        ref: drop(ref),
        ...props,
        children: component.children.map((key)=>/*#__PURE__*/ jsx_runtime_.jsx(editor_ComponentPreview, {
                componentName: key
            }, key))
    });
};
const AccordionItemPreview = ({ component  })=>{
    const { props , ref  } = useInteractive(component, true);
    const { drop , isOver  } = useDropComponent(component.id, AccordionWhitelist);
    let boxProps = {};
    if (isOver) {
        props.bg = "teal.50";
    }
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
        ref: drop(ref),
        ...boxProps,
        children: /*#__PURE__*/ jsx_runtime_.jsx(react_.AccordionItem, {
            ...props,
            children: component.children.map((key)=>/*#__PURE__*/ jsx_runtime_.jsx(editor_ComponentPreview, {
                    componentName: key
                }, key))
        })
    });
};
const AccordionPanelPreview = ({ component  })=>{
    const { props , ref  } = useInteractive(component, true);
    const { drop , isOver  } = useDropComponent(component.id, AccordionWhitelist);
    let boxProps = {};
    if (isOver) {
        props.bg = "teal.50";
    }
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
        ref: drop(ref),
        ...boxProps,
        children: /*#__PURE__*/ jsx_runtime_.jsx(react_.AccordionPanel, {
            ...props,
            children: component.children.map((key)=>/*#__PURE__*/ jsx_runtime_.jsx(editor_ComponentPreview, {
                    componentName: key
                }, key))
        })
    });
};
/* harmony default export */ const previews_AccordionPreview = (AccordionPreview);

;// CONCATENATED MODULE: ./src/components/editor/previews/InputRightElement.tsx






const InputRightElementPreview = ({ component ,  })=>{
    const { drop , isOver  } = useDropComponent(component.id);
    const { props , ref  } = useInteractive(component, true);
    if (isOver) {
        props.bg = "teal.50";
    }
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.InputRightElement, {
        top: "10px",
        right: "10px",
        ...props,
        ref: drop(ref),
        children: component.children.map((key)=>/*#__PURE__*/ jsx_runtime_.jsx(editor_ComponentPreview, {
                componentName: key
            }, key))
    });
};

;// CONCATENATED MODULE: ./src/components/editor/previews/InputLeftElement.tsx






const InputLeftElementPreview = ({ component ,  })=>{
    const { drop , isOver  } = useDropComponent(component.id);
    const { props , ref  } = useInteractive(component, true);
    if (isOver) {
        props.bg = "teal.50";
    }
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.InputLeftElement, {
        top: "10px",
        right: "10px",
        ...props,
        ref: drop(ref),
        children: component.children.map((key, i)=>/*#__PURE__*/ jsx_runtime_.jsx(editor_ComponentPreview, {
                componentName: key
            }, i))
    });
};

;// CONCATENATED MODULE: ./src/components/editor/previews/AspectRatioBoxPreview.tsx






const AspectRatioPreview = ({ component ,  })=>{
    const { props , ref  } = useInteractive(component, true);
    const { drop , isOver  } = useDropComponent(component.id, undefined, component.children.length === 0);
    const children = component.children;
    const boxProps = {};
    if (isOver) {
        props.bg = "teal.50";
    }
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
        ...boxProps,
        ref: drop(ref),
        children: /*#__PURE__*/ jsx_runtime_.jsx(react_.AspectRatio, {
            ...props,
            children: !children.length ? /*
           * We need at least one children because of the implementation
           * of AspectRatio
           */ /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {}) : /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(editor_ComponentPreview, {
                    componentName: children[0]
                })
            })
        })
    });
};
/* harmony default export */ const AspectRatioBoxPreview = (AspectRatioPreview);

// EXTERNAL MODULE: ./src/iconsList.ts
var iconsList = __webpack_require__(8081);
;// CONCATENATED MODULE: ./src/components/editor/previews/ButtonPreview.tsx






const ButtonPreview = ({ component  })=>{
    const { isOver  } = useDropComponent(component.id);
    const { props , ref  } = useInteractive(component, true);
    if (isOver) {
        props.bg = "teal.50";
    }
    if (props.leftIcon) {
        if (Object.keys(iconsList/* default */.Z).includes(props.leftIcon)) {
            const Icon = iconsList/* default */.Z[props.leftIcon];
            props.leftIcon = /*#__PURE__*/ jsx_runtime_.jsx(Icon, {
                path: ""
            });
        } else {
            props.leftIcon = undefined;
        }
    }
    if (props.rightIcon) {
        if (Object.keys(iconsList/* default */.Z).includes(props.rightIcon)) {
            const Icon1 = iconsList/* default */.Z[props.rightIcon];
            props.rightIcon = /*#__PURE__*/ jsx_runtime_.jsx(Icon1, {
                path: ""
            });
        } else {
            props.rightIcon = undefined;
        }
    }
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.Button, {
        ref: ref,
        ...props
    });
};
/* harmony default export */ const previews_ButtonPreview = (ButtonPreview);

;// CONCATENATED MODULE: ./src/components/editor/PreviewContainer.tsx




const PreviewContainer = ({ component , type , enableVisualHelper , isBoxWrapped , ...forwardedProps })=>{
    const { props , ref  } = useInteractive(component, enableVisualHelper);
    const children = /*#__PURE__*/ external_react_default().createElement(type, {
        ...props,
        ...forwardedProps,
        ref
    });
    if (isBoxWrapped) {
        let boxProps = {};
        return /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
            ...boxProps,
            ref: ref,
            children: children
        });
    }
    return children;
};
/* harmony default export */ const editor_PreviewContainer = (PreviewContainer);

;// CONCATENATED MODULE: ./src/components/editor/WithChildrenPreviewContainer.tsx






const WithChildrenPreviewContainer = ({ component , type , enableVisualHelper =false , isBoxWrapped , ...forwardedProps })=>{
    const { drop , isOver  } = useDropComponent(component.id);
    const { props , ref  } = useInteractive(component, enableVisualHelper);
    const propsElement = {
        ...props,
        ...forwardedProps,
        pos: "relative"
    };
    if (!isBoxWrapped) {
        propsElement.ref = drop(ref);
    }
    if (isOver) {
        propsElement.bg = "teal.50";
    }
    const children = /*#__PURE__*/ external_react_default().createElement(type, propsElement, component.children.map((key)=>/*#__PURE__*/ jsx_runtime_.jsx(editor_ComponentPreview, {
            componentName: key
        }, key)));
    if (isBoxWrapped) {
        let boxProps = {
            display: "inline"
        };
        return /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
            ...boxProps,
            ref: drop(ref),
            children: children
        });
    }
    return children;
};
/* harmony default export */ const editor_WithChildrenPreviewContainer = (WithChildrenPreviewContainer);

;// CONCATENATED MODULE: ./src/components/editor/previews/IconPreview.tsx






const IconPreview = ({ component  })=>{
    const { isOver  } = useDropComponent(component.id);
    const { props: { color , boxSize , icon , ...props } ,  } = useInteractive(component, true);
    if (isOver) {
        props.bg = "teal.50";
    }
    if (icon) {
        if (Object.keys(iconsList/* default */.Z).includes(icon)) {
            const Icon = iconsList/* default */.Z[icon];
            return /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
                ...props,
                display: "inline",
                children: /*#__PURE__*/ jsx_runtime_.jsx(Icon, {
                    path: "",
                    color: color,
                    boxSize: boxSize
                })
            });
        }
        return null;
    }
    return null;
};
/* harmony default export */ const previews_IconPreview = (IconPreview);

;// CONCATENATED MODULE: ./src/components/editor/previews/IconButtonPreview.tsx






const IconButtonPreview = ({ component  })=>{
    const { isOver  } = useDropComponent(component.id);
    const { props: { icon , ...props } , ref ,  } = useInteractive(component, true);
    if (isOver) {
        props.bg = "teal.50";
    }
    if (icon) {
        if (Object.keys(iconsList/* default */.Z).includes(icon)) {
            const Icon = iconsList/* default */.Z[icon];
            return /*#__PURE__*/ jsx_runtime_.jsx(react_.IconButton, {
                ref: ref,
                icon: /*#__PURE__*/ jsx_runtime_.jsx(Icon, {
                    path: ""
                }),
                ...props
            });
        }
        return null;
    }
    return null;
};
/* harmony default export */ const previews_IconButtonPreview = (IconButtonPreview);

;// CONCATENATED MODULE: ./src/components/editor/previews/SelectPreview.tsx





const SelectPreview = ({ component  })=>{
    const { props: { icon , ...props } ,  } = useInteractive(component);
    const Icon = (0,external_react_.useMemo)(()=>{
        if (!icon) {
            return null;
        }
        return iconsList/* default */.Z[icon];
    }, [
        icon
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Select, {
        ...props,
        icon: Icon ? /*#__PURE__*/ jsx_runtime_.jsx(Icon, {
            path: ""
        }) : undefined,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                value: "option1",
                children: "Option 1"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                value: "option2",
                children: "Option 2"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                value: "option3",
                children: "Option 3"
            })
        ]
    });
};
/* harmony default export */ const previews_SelectPreview = (SelectPreview);

;// CONCATENATED MODULE: ./src/components/editor/previews/NumberInputPreview.tsx




const NumberInputPreview = ({ component  })=>{
    const { props  } = useInteractive(component);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.NumberInput, {
        ...props,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(react_.NumberInputField, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.NumberInputStepper, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(react_.NumberIncrementStepper, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(react_.NumberDecrementStepper, {})
                ]
            })
        ]
    });
};
/* harmony default export */ const previews_NumberInputPreview = (NumberInputPreview);

;// CONCATENATED MODULE: ./src/components/editor/previews/BreadcrumbPreview.tsx






const BreadcrumbPreview = ({ component  })=>{
    const acceptedTypes = [
        "BreadcrumbItem",
        "BreadcrumbLink"
    ];
    const { props , ref  } = useInteractive(component, false);
    const { drop , isOver  } = useDropComponent(component.id, acceptedTypes);
    let boxProps = {};
    if (isOver) {
        props.bg = "teal.50";
    }
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
        ref: drop(ref),
        ...boxProps,
        children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Breadcrumb, {
            ...props,
            children: component.children.map((key)=>/*#__PURE__*/ jsx_runtime_.jsx(editor_ComponentPreview, {
                    componentName: key
                }, key))
        })
    });
};
/* harmony default export */ const previews_BreadcrumbPreview = (BreadcrumbPreview);

;// CONCATENATED MODULE: ./src/components/editor/previews/BreadcrumbItemPreview.tsx






const BreadcrumbItemPreview = ({ component  })=>{
    const acceptedTypes = [
        "BreadcrumbLink"
    ];
    const { props , ref  } = useInteractive(component, true);
    const { drop , isOver  } = useDropComponent(component.id, acceptedTypes);
    if (isOver) {
        props.bg = "teal.50";
    }
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.BreadcrumbItem, {
        ...props,
        ref: drop(ref),
        children: component.children.map((key)=>/*#__PURE__*/ jsx_runtime_.jsx(editor_ComponentPreview, {
                componentName: key
            }, key))
    });
};
/* harmony default export */ const previews_BreadcrumbItemPreview = (BreadcrumbItemPreview);

;// CONCATENATED MODULE: ./src/components/editor/previews/HighlightPreview.tsx




const HighlightPreview = ({ component  })=>{
    const { props , ref  } = useInteractive(component, true, true);
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
        ...props,
        ref: ref,
        children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Highlight, {
            ...component.props,
            styles: component.props
        })
    });
};
/* harmony default export */ const previews_HighlightPreview = (HighlightPreview);

;// CONCATENATED MODULE: ./src/components/editor/previews/SkeletonPreview.tsx






const SkeletonPreview = ({ component ,  })=>{
    const { drop , isOver  } = useDropComponent(component.id);
    const { props , ref  } = useInteractive(component, true, true);
    if (isOver) {
        props.bg = "teal.50";
    }
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
        ref: drop(ref),
        ...props,
        m: 0,
        children: /*#__PURE__*/ jsx_runtime_.jsx(react_.Skeleton, {
            ...component.props,
            children: component.children.map((key)=>/*#__PURE__*/ jsx_runtime_.jsx(editor_ComponentPreview, {
                    componentName: key
                }, key))
        })
    });
};
const SkeletonTextPreview = ({ component  })=>{
    const { props , ref  } = useInteractive(component, true);
    const { drop , isOver  } = useDropComponent(component.id);
    let boxProps = {};
    if (isOver) {
        props.bg = "teal.50";
    }
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
        ref: drop(ref),
        ...boxProps,
        children: /*#__PURE__*/ jsx_runtime_.jsx(react_.SkeletonText, {
            ...props,
            children: component.children.map((key)=>/*#__PURE__*/ jsx_runtime_.jsx(editor_ComponentPreview, {
                    componentName: key
                }, key))
        })
    });
};
const SkeletonCirclePreview = ({ component  })=>{
    const { props , ref  } = useInteractive(component, true, true);
    const { drop , isOver  } = useDropComponent(component.id);
    if (isOver) {
        props.bg = "teal.50";
    }
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.Box, {
        display: "inline-block",
        ref: drop(ref),
        ...props,
        children: /*#__PURE__*/ jsx_runtime_.jsx(react_.SkeletonCircle, {
            ...component.props,
            children: component.children.map((key)=>/*#__PURE__*/ jsx_runtime_.jsx(editor_ComponentPreview, {
                    componentName: key
                }, key))
        })
    });
};
/* harmony default export */ const previews_SkeletonPreview = (SkeletonPreview);

;// CONCATENATED MODULE: ./src/components/editor/ComponentPreview.tsx






















const ComponentPreview = ({ componentName , ...forwardedProps })=>{
    const component = (0,external_react_redux_.useSelector)((0,selectors_components/* getComponentBy */.kW)(componentName));
    if (!component) {
        console.error(`ComponentPreview unavailable for component ${componentName}`);
    }
    const type = component && component.type || null;
    switch(type){
        // Simple components
        case "Badge":
        case "Image":
        case "Text":
        case "Link":
        case "Spinner":
        case "Checkbox":
        case "Textarea":
        case "CircularProgress":
        case "Heading":
        case "Switch":
        case "FormLabel":
        case "FormHelperText":
        case "FormErrorMessage":
        case "TabPanel":
        case "Tab":
        case "Input":
        case "Radio":
        case "ListItem":
        case "BreadcrumbLink":
        case "Kbd":
        case "StatLabel":
        case "StatNumber":
        case "StatArrow":
            return /*#__PURE__*/ jsx_runtime_.jsx(editor_PreviewContainer, {
                component: component,
                type: react_[type],
                ...forwardedProps
            });
        // Wrapped functional components (forward ref issue)
        case "AlertIcon":
        case "Progress":
        case "CloseButton":
        case "AccordionIcon":
        case "Code":
        case "ListIcon":
        case "Divider":
        case "AlertDescription":
        case "AlertTitle":
        case "InputRightAddon":
        case "InputLeftAddon":
        case "Tag":
            return /*#__PURE__*/ jsx_runtime_.jsx(editor_PreviewContainer, {
                component: component,
                type: react_[type],
                ...forwardedProps,
                isBoxWrapped: true
            });
        // Components with childrens
        case "Box":
        case "SimpleGrid":
        case "Flex":
        case "FormControl":
        case "Tabs":
        case "List":
        case "TabList":
        case "TabPanels":
        case "Grid":
        case "Center":
        case "Container":
            return /*#__PURE__*/ jsx_runtime_.jsx(editor_WithChildrenPreviewContainer, {
                enableVisualHelper: true,
                component: component,
                type: react_[type],
                ...forwardedProps
            });
        case "RadioGroup":
        case "Stack":
        case "InputGroup":
            return /*#__PURE__*/ jsx_runtime_.jsx(editor_WithChildrenPreviewContainer, {
                enableVisualHelper: true,
                component: component,
                type: react_[type],
                ...forwardedProps,
                isBoxWrapped: true
            });
        // More complex components
        case "InputRightElement":
            return /*#__PURE__*/ jsx_runtime_.jsx(InputRightElementPreview, {
                component: component
            });
        case "InputLeftElement":
            return /*#__PURE__*/ jsx_runtime_.jsx(InputLeftElementPreview, {
                component: component
            });
        case "Avatar":
            return /*#__PURE__*/ jsx_runtime_.jsx(previews_AvatarPreview, {
                component: component
            });
        case "AvatarBadge":
            return /*#__PURE__*/ jsx_runtime_.jsx(AvatarBadgePreview, {
                component: component
            });
        case "AvatarGroup":
            return /*#__PURE__*/ jsx_runtime_.jsx(AvatarGroupPreview, {
                component: component
            });
        case "Alert":
            return /*#__PURE__*/ jsx_runtime_.jsx(previews_AlertPreview, {
                component: component
            });
        case "Accordion":
            return /*#__PURE__*/ jsx_runtime_.jsx(previews_AccordionPreview, {
                component: component
            });
        case "AccordionButton":
            return /*#__PURE__*/ jsx_runtime_.jsx(AccordionButtonPreview, {
                component: component
            });
        case "AccordionItem":
            return /*#__PURE__*/ jsx_runtime_.jsx(AccordionItemPreview, {
                component: component
            });
        case "AccordionPanel":
            return /*#__PURE__*/ jsx_runtime_.jsx(AccordionPanelPreview, {
                component: component
            });
        case "AspectRatio":
            return /*#__PURE__*/ jsx_runtime_.jsx(AspectRatioBoxPreview, {
                component: component
            });
        case "Button":
            return /*#__PURE__*/ jsx_runtime_.jsx(previews_ButtonPreview, {
                component: component
            });
        case "Breadcrumb":
            return /*#__PURE__*/ jsx_runtime_.jsx(previews_BreadcrumbPreview, {
                component: component
            });
        case "BreadcrumbItem":
            return /*#__PURE__*/ jsx_runtime_.jsx(previews_BreadcrumbItemPreview, {
                component: component
            });
        case "Icon":
            return /*#__PURE__*/ jsx_runtime_.jsx(previews_IconPreview, {
                component: component
            });
        case "IconButton":
            return /*#__PURE__*/ jsx_runtime_.jsx(previews_IconButtonPreview, {
                component: component
            });
        case "Select":
            return /*#__PURE__*/ jsx_runtime_.jsx(previews_SelectPreview, {
                component: component
            });
        case "NumberInput":
            return /*#__PURE__*/ jsx_runtime_.jsx(previews_NumberInputPreview, {
                component: component
            });
        case "Highlight":
            return /*#__PURE__*/ jsx_runtime_.jsx(previews_HighlightPreview, {
                component: component
            });
        case "Skeleton":
            return /*#__PURE__*/ jsx_runtime_.jsx(previews_SkeletonPreview, {
                component: component
            });
        case "SkeletonText":
            return /*#__PURE__*/ jsx_runtime_.jsx(SkeletonTextPreview, {
                component: component
            });
        case "SkeletonCircle":
            return /*#__PURE__*/ jsx_runtime_.jsx(SkeletonCirclePreview, {
                component: component
            });
        default:
            return null;
    }
};
/* harmony default export */ const editor_ComponentPreview = (/*#__PURE__*/(0,external_react_.memo)(ComponentPreview));

;// CONCATENATED MODULE: ./src/components/editor/Editor.tsx











const gridStyles = {
    backgroundImage: "linear-gradient(to right, #d9e2e9 1px, transparent 1px),linear-gradient(to bottom, #d9e2e9 1px, transparent 1px);",
    backgroundSize: "20px 20px",
    bgColor: "#edf2f6",
    p: 10
};
const Editor = ()=>{
    const showCode = (0,external_react_redux_.useSelector)(app/* getShowCode */.Tz);
    const showLayout = (0,external_react_redux_.useSelector)(app/* getShowLayout */.tk);
    const components = (0,external_react_redux_.useSelector)(selectors_components/* getComponents */.OQ);
    const dispatch = (0,useDispatch/* default */.Z)();
    const { drop  } = useDropComponent("root");
    const isEmpty = !components.root.children.length;
    const rootProps = components.root.props;
    let editorBackgroundProps = {};
    const onSelectBackground = ()=>{
        dispatch.components.unselect();
    };
    if (showLayout) {
        editorBackgroundProps = gridStyles;
    }
    editorBackgroundProps = {
        ...editorBackgroundProps,
        ...rootProps
    };
    const Playground = /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Box, {
        p: 2,
        ...editorBackgroundProps,
        height: "100%",
        minWidth: "10rem",
        width: "100%",
        display: isEmpty ? "flex" : "block",
        justifyContent: "center",
        alignItems: "center",
        overflow: "auto",
        ref: drop,
        position: "relative",
        flexDirection: "column",
        onClick: onSelectBackground,
        children: [
            isEmpty && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Text, {
                maxWidth: "md",
                color: "gray.400",
                fontSize: "xl",
                textAlign: "center",
                children: [
                    "Drag some component to start coding without code! Or load",
                    " ",
                    /*#__PURE__*/ jsx_runtime_.jsx(react_.Link, {
                        color: "gray.500",
                        onClick: (e)=>{
                            e.stopPropagation();
                            dispatch.components.loadDemo("onboarding");
                        },
                        textDecoration: "underline",
                        children: "the onboarding components"
                    }),
                    "."
                ]
            }),
            components.root.children.map((name)=>/*#__PURE__*/ jsx_runtime_.jsx(editor_ComponentPreview, {
                    componentName: name
                }, name))
        ]
    });
    if (!showCode) {
        return Playground;
    }
    return(// @ts-ignore
    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((external_react_split_pane_default()), {
        style: {
            overflow: "auto"
        },
        defaultSize: "50%",
        resizerStyle: {
            border: "3px solid rgba(1, 22, 39, 0.21)",
            zIndex: 20,
            cursor: "row-resize"
        },
        split: "horizontal",
        children: [
            Playground,
            /*#__PURE__*/ jsx_runtime_.jsx(components_CodePanel, {})
        ]
    }));
};
/* harmony default export */ const editor_Editor = (/*#__PURE__*/(0,external_react_.memo)(Editor));


/***/ }),

/***/ 4203:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tz": () => (/* binding */ getShowCode),
/* harmony export */   "k7": () => (/* binding */ getInputTextFocused),
/* harmony export */   "qs": () => (/* binding */ getFocusedComponent),
/* harmony export */   "tk": () => (/* binding */ getShowLayout)
/* harmony export */ });
const getShowLayout = (state)=>state.app.showLayout;
const getShowCode = (state)=>state.app.showCode;
const getFocusedComponent = (id)=>(state)=>state.app.inputTextFocused && state.components.present.selectedId === id;
const getInputTextFocused = (state)=>state.app.inputTextFocused;


/***/ }),

/***/ 4179:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Dz": () => (/* binding */ getSelectedComponent),
/* harmony export */   "OQ": () => (/* binding */ getComponents),
/* harmony export */   "OX": () => (/* binding */ getSelectedComponentId),
/* harmony export */   "QT": () => (/* binding */ getSelectedComponentParent),
/* harmony export */   "_y": () => (/* binding */ getIsSelectedComponent),
/* harmony export */   "kW": () => (/* binding */ getComponentBy),
/* harmony export */   "ll": () => (/* binding */ getSelectedComponentChildren),
/* harmony export */   "mI": () => (/* binding */ getIsHovered),
/* harmony export */   "yC": () => (/* binding */ getComponentNames)
/* harmony export */ });
/* unused harmony exports getPropsForSelectedComponent, getHoveredId */
/* harmony import */ var lodash_map__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3707);
/* harmony import */ var lodash_map__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash_map__WEBPACK_IMPORTED_MODULE_0__);

const getComponents = (state)=>state.components.present.components;
const getComponentBy = (nameOrId)=>(state)=>state.components.present.components[nameOrId];
const getSelectedComponent = (state)=>state.components.present.components[state.components.present.selectedId];
const getPropsForSelectedComponent = (state, propsName)=>state.components.present.components[state.components.present.selectedId].props[propsName];
const getSelectedComponentId = (state)=>state.components.present.selectedId;
const getIsSelectedComponent = (componentId)=>(state)=>state.components.present.selectedId === componentId;
const getSelectedComponentChildren = (state)=>{
    return getSelectedComponent(state).children.map((child)=>getComponentBy(child)(state));
};
const getSelectedComponentParent = (state)=>state.components.present.components[getSelectedComponent(state).parent];
const getHoveredId = (state)=>state.components.present.hoveredId;
const getIsHovered = (id)=>(state)=>getHoveredId(state) === id;
const getComponentNames = (state)=>{
    const names = lodash_map__WEBPACK_IMPORTED_MODULE_0___default()(state.components.present.components, (comp)=>comp.componentName).filter((comp)=>!!comp);
    return Array.from(new Set(names));
};


/***/ }),

/***/ 5690:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_0__);

const useDispatch = ()=>{
    return (0,react_redux__WEBPACK_IMPORTED_MODULE_0__.useDispatch)();
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useDispatch);


/***/ }),

/***/ 8081:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _chakra_ui_icons__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4513);
/* harmony import */ var _chakra_ui_icons__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_chakra_ui_icons__WEBPACK_IMPORTED_MODULE_0__);

const { createIcon , ...iconsList } = _chakra_ui_icons__WEBPACK_IMPORTED_MODULE_0__;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (iconsList);


/***/ }),

/***/ 2034:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "R": () => (/* binding */ bugsnagClient),
/* harmony export */   "S": () => (/* binding */ ErrorBoundary)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _bugsnag_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2453);
/* harmony import */ var _bugsnag_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_bugsnag_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _bugsnag_plugin_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7736);
/* harmony import */ var _bugsnag_plugin_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_bugsnag_plugin_react__WEBPACK_IMPORTED_MODULE_2__);



const bugsnagClient = _bugsnag_js__WEBPACK_IMPORTED_MODULE_1___default()({
    apiKey: "18bc83982a86e6477448b6bc16c0c18e",
    releaseStage: "production",
    notifyReleaseStages: [
        "production"
    ]
});
bugsnagClient.use((_bugsnag_plugin_react__WEBPACK_IMPORTED_MODULE_2___default()), (react__WEBPACK_IMPORTED_MODULE_0___default()));
const ErrorBoundary = bugsnagClient.getPlugin("react");


/***/ }),

/***/ 8453:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Bi": () => (/* binding */ generateComponentCode),
/* harmony export */   "XQ": () => (/* binding */ formatCode),
/* harmony export */   "bB": () => (/* binding */ generateCode)
/* harmony export */ });
/* harmony import */ var lodash_isBoolean__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2327);
/* harmony import */ var lodash_isBoolean__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash_isBoolean__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var lodash_filter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9368);
/* harmony import */ var lodash_filter__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash_filter__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _iconsList__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8081);



const capitalize = (value)=>{
    return value.charAt(0).toUpperCase() + value.slice(1);
};
const formatCode = async (code)=>{
    let formattedCode = `// 🚨 Your props contains invalid code`;
    const prettier = await Promise.resolve(/* import() */).then(__webpack_require__.t.bind(__webpack_require__, 7413, 23));
    const babylonParser = await Promise.resolve(/* import() */).then(__webpack_require__.t.bind(__webpack_require__, 9761, 23));
    try {
        formattedCode = prettier.format(code, {
            parser: "babel",
            plugins: [
                babylonParser
            ],
            semi: false,
            singleQuote: true
        });
    } catch (e) {}
    return formattedCode;
};
const buildStyledProps = (propsNames, childComponent)=>{
    let propsContent = ``;
    propsNames.forEach((propName)=>{
        const propsValue = childComponent.props[propName];
        if (propName.toLowerCase().includes("icon") && childComponent.type !== "Icon") {
            if (Object.keys(_iconsList__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z).includes(propsValue)) {
                let operand = `={<${propsValue} />}`;
                propsContent += `${propName}${operand} `;
            }
        } else if (propName !== "children" && propsValue) {
            let operand1 = `='${propsValue}'`;
            if (propsValue === true || propsValue === "true") {
                operand1 = ``;
            } else if (propsValue === "false" || lodash_isBoolean__WEBPACK_IMPORTED_MODULE_0___default()(propsValue) || !isNaN(propsValue)) {
                operand1 = `={${propsValue}}`;
            }
            propsContent += `${propName}${operand1} `;
        }
    });
    return propsContent;
};
const buildBlock = ({ component , components , forceBuildBlock =false  })=>{
    let content = "";
    component.children.forEach((key)=>{
        let childComponent = components[key];
        if (!childComponent) {
            console.error(`invalid component ${key}`);
        } else if (forceBuildBlock || !childComponent.componentName) {
            const componentName = capitalize(childComponent.type);
            let propsContent = "";
            const propsNames = Object.keys(childComponent.props).filter((propName)=>{
                if (childComponent.type === "Icon") {
                    return propName !== "icon";
                }
                return true;
            });
            // Special case for Highlight component
            if (componentName === "Highlight") {
                const [query, children, ...restProps] = propsNames;
                propsContent += buildStyledProps([
                    query,
                    children
                ], childComponent);
                propsContent += `styles={{${restProps.filter((propName)=>childComponent.props[propName]).map((propName)=>`${propName}:'${childComponent.props[propName]}'`)}}}`;
            } else {
                propsContent += buildStyledProps(propsNames, childComponent);
            }
            if (typeof childComponent.props.children === "string" && childComponent.children.length === 0) {
                content += `<${componentName} ${propsContent}>${childComponent.props.children}</${componentName}>`;
            } else if (childComponent.type === "Icon") {
                content += `<${childComponent.props.icon} ${propsContent} />`;
            } else if (childComponent.children.length) {
                content += `<${componentName} ${propsContent}>
      ${buildBlock({
                    component: childComponent,
                    components,
                    forceBuildBlock
                })}
      </${componentName}>`;
            } else {
                content += `<${componentName} ${propsContent} />`;
            }
        } else {
            content += `<${childComponent.componentName} />`;
        }
    });
    return content;
};
const buildComponents = (components)=>{
    const codes = lodash_filter__WEBPACK_IMPORTED_MODULE_1___default()(components, (comp)=>!!comp.componentName).map((comp)=>{
        return generateComponentCode({
            component: {
                ...components[comp.parent],
                children: [
                    comp.id
                ]
            },
            components,
            forceBuildBlock: true,
            componentName: comp.componentName
        });
    });
    return codes.reduce((acc, val)=>{
        return `
      ${acc}

      ${val}
    `;
    }, "");
};
const generateComponentCode = ({ component , components , componentName , forceBuildBlock  })=>{
    let code = buildBlock({
        component,
        components,
        forceBuildBlock
    });
    code = `
const ${componentName} = () => (
  ${code}
)`;
    return code;
};
const getIconsImports = (components)=>{
    return Object.keys(components).flatMap((name)=>{
        return Object.keys(components[name].props).filter((prop)=>prop.toLowerCase().includes("icon")).filter((prop)=>!!components[name].props[prop]).map((prop)=>components[name].props[prop]);
    });
};
const generateCode = async (components)=>{
    let code = buildBlock({
        component: components.root,
        components
    });
    let componentsCodes = buildComponents(components);
    const iconImports = Array.from(new Set(getIconsImports(components)));
    const imports = [
        ...new Set(Object.keys(components).filter((name)=>name !== "root").map((name)=>components[name].type)), 
    ];
    code = `import React from 'react';
import {
  ChakraProvider,
  ${imports.join(",")}
} from "@chakra-ui/react";${iconImports.length ? `
import { ${iconImports.join(",")} } from "@chakra-ui/icons";` : ""}

${componentsCodes}

const App = () => (
  <ChakraProvider resetCSS>
    ${code}
  </ChakraProvider>
);

export default App;`;
    return await formatCode(code);
};


/***/ }),

/***/ 9737:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "K": () => (/* binding */ getDefaultFormProps),
/* harmony export */   "n": () => (/* binding */ DEFAULT_PROPS)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8930);
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__);



const DEFAULT_PROPS = {
    AlertDescription: {
        children: "Alert description"
    },
    AlertTitle: {
        children: "Alert title",
        mr: 1,
        fontWeight: "bold"
    },
    AvatarBadge: {
        bg: "green.500",
        boxSize: "1.25rem",
        borderColor: "white"
    },
    AvatarGroup: {
        spacing: -3,
        max: 3,
        size: "md",
        form: {
            display: "flex"
        }
    },
    Badge: {
        children: "Badge name",
        variant: "subtle"
    },
    Breadcrumb: {
        form: {
            separator: "/"
        }
    },
    BreadcrumbLink: {
        children: "Lorem Ipsum"
    },
    Button: {
        children: "Button text",
        variant: "solid",
        size: "md"
    },
    Checkbox: {
        children: "Label checkbox",
        isReadOnly: true,
        isChecked: false
    },
    CircularProgress: {
        size: "48px",
        value: 60,
        min: 0,
        max: 100
    },
    CloseButton: {
        size: "md"
    },
    Code: {
        children: "Code value"
    },
    Divider: {
        borderColor: "blackAlpha.500"
    },
    Flex: {
        form: {
            display: "flex"
        }
    },
    FormLabel: {
        children: "Label"
    },
    FormHelperText: {
        children: "Helper message"
    },
    FormErrorMessage: {
        children: "Error message"
    },
    Grid: {
        templateColumns: "repeat(5, 1fr)",
        gap: 6,
        form: {
            display: "grid"
        }
    },
    Heading: {
        children: "Heading title"
    },
    Highlight: {
        children: "Heading title",
        query: "title"
    },
    Icon: {
        icon: "CopyIcon"
    },
    IconButton: {
        "aria-label": "icon",
        // @ts-ignore
        icon: "CopyIcon",
        size: "md"
    },
    Image: {
        height: "100px",
        width: "100px"
    },
    InputLeftAddon: {
        children: "left"
    },
    InputRightAddon: {
        children: "right"
    },
    Link: {
        children: "Link text"
    },
    List: {
        form: {
            styleType: "none"
        }
    },
    ListItem: {
        children: "list"
    },
    Kbd: {
        children: "shift"
    },
    Progress: {
        value: 60,
        min: 0,
        max: 100
    },
    Radio: {
        children: "Radio"
    },
    Select: {
        // @ts-ignore
        icon: "ChevronDownIcon",
        variant: "outline",
        size: "md",
        // @ts-ignore
        form: {
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                        value: "option1",
                        children: "Option 1"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                        value: "option2",
                        children: "Option 2"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                        value: "option3",
                        children: "Option 3"
                    })
                ]
            })
        }
    },
    SimpleGrid: {
        columns: 2,
        spacingX: 1,
        spacingY: 1
    },
    Stack: {
        spacing: 2,
        form: {
            display: "flex"
        }
    },
    Stat: {},
    StatLabel: {
        children: "Stat label"
    },
    StatNumber: {
        children: "45"
    },
    StatArrow: {
        type: "increase"
    },
    StatHelpText: {
        display: "flex",
        alignItems: "center"
    },
    StatGroup: {},
    Skeleton: {
        height: 50,
        form: {
            fadeDuration: 0.4,
            speed: 0.8
        }
    },
    SkeletonCircle: {
        form: {
            fadeDuration: 0.4,
            speed: 0.8
        }
    },
    SkeletonText: {
        form: {
            fadeDuration: 0.4,
            speed: 0.8
        }
    },
    Switch: {
        isChecked: false
    },
    Tab: {
        children: "Tab"
    },
    Tabs: {
        children: "",
        size: "md"
    },
    TabPanel: {
        children: "Tab"
    },
    Tag: {
        children: "Tag name"
    },
    Text: {
        children: "Text value"
    }
};
const getDefaultFormProps = (type)=>{
    //@ts-ignore
    const chakraDefaultProps = _chakra_ui_react__WEBPACK_IMPORTED_MODULE_2__[type].defaultProps;
    // @ts-ignore
    return {
        ...chakraDefaultProps,
        ...DEFAULT_PROPS[type]?.form
    };
};


/***/ }),

/***/ 427:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "O": () => (/* binding */ generateId)
/* harmony export */ });
const generateId = ()=>{
    return `comp-${(Date.now().toString(36) + Math.random().toString(36).substr(2, 5)).toUpperCase()}`;
};


/***/ })

};
;